import { useState } from 'react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Waitlist signup:', email);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  if (submitted) {
    return (
      <div className="text-[#b3b3b3]">
        Thanks. We'll be in touch.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-3 max-w-lg">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="your@email.com"
        className="flex-1 px-4 py-3 bg-[#1a1a1a] border border-[#333333] rounded text-white placeholder-[#666666] outline-none focus:border-[#666666] transition-colors"
        required
      />
      <button
        type="submit"
        className="px-6 py-3 bg-white text-black rounded hover:bg-[#e6e6e6] transition-colors"
      >
        Join waitlist
      </button>
    </form>
  );
}
