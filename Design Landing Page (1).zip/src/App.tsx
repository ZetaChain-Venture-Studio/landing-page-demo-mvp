import { WaitlistForm } from './components/WaitlistForm';
import { ModelSwitcher } from './components/ModelSwitcher';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0d0d0d] text-white">
      {/* Header */}
      <header className="border-b border-[#222222]">
        <div className="max-w-5xl mx-auto px-6 py-6">
          <span className="text-sm">ANUMA</span>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-5xl mx-auto px-6 py-32">
        <div className="max-w-3xl">
          <h1 className="text-6xl md:text-7xl mb-8 leading-[1.1]">
            Stop paying for multiple AI subscriptions
          </h1>
          
          <p className="text-xl text-[#b3b3b3] mb-12 leading-relaxed max-w-2xl">
            ANUMA gives you access to GPT-4, Claude, Gemini, and Llama in one place. Switch between models instantly while keeping your conversation context. Everything stored locally in your browser.
          </p>
          
          <WaitlistForm />
        </div>

        {/* Model Switcher Demo */}
        <div className="mt-32 mb-16">
          <ModelSwitcher />
        </div>

        {/* Simple feature list */}
        <div className="border-t border-[#222222] pt-16 mt-32">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <h3 className="text-lg mb-3">Switch freely</h3>
              <p className="text-[#808080] text-sm leading-relaxed">
                Change AI models mid-conversation without losing context or having to explain yourself again.
              </p>
            </div>
            <div>
              <h3 className="text-lg mb-3">Your data, your device</h3>
              <p className="text-[#808080] text-sm leading-relaxed">
                All conversations and history are stored locally in your browser. Nothing leaves your computer.
              </p>
            </div>
            <div>
              <h3 className="text-lg mb-3">One subscription</h3>
              <p className="text-[#808080] text-sm leading-relaxed">
                Access every major AI model through a single interface instead of managing multiple accounts.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#222222] mt-32">
        <div className="max-w-5xl mx-auto px-6 py-8">
          <div className="flex justify-between items-center text-sm text-[#808080]">
            <span>© 2024 ANUMA</span>
            <div className="flex gap-8">
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}