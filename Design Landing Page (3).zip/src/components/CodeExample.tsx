export function CodeExample() {
  return (
    <div className="bg-[#111] border border-white/10 rounded-lg overflow-hidden font-mono text-sm">
      <div className="border-b border-white/10 px-4 py-2 text-xs text-white/40 flex items-center justify-between">
        <span>example.js</span>
        <span className="text-[10px]">JavaScript</span>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="text-white/80">
{`import { ANUMA } from '@anuma/sdk';

const anuma = new ANUMA({
  apiKey: process.env.ANUMA_API_KEY
});

// Start with Claude for creative writing
const thread = await anuma.chat({
  model: 'claude',
  message: 'Write a product tagline'
});

// Switch to GPT-4 for technical analysis
await anuma.chat({
  threadId: thread.id,
  model: 'gpt-4',
  message: 'Now analyze conversion metrics'
});

// Context preserved across models ✓`}</pre>
      </div>
    </div>
  );
}
