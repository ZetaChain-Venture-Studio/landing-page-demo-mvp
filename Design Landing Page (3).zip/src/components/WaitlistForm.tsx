import { useState } from 'react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Waitlist signup:', email);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  if (submitted) {
    return (
      <div className="text-white/40 font-mono text-sm">
        → Request received. Check your inbox for API key.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 max-w-md mx-auto">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="developer@company.com"
        className="flex-1 px-4 py-3 bg-white/5 border border-white/20 outline-none focus:border-white/40 transition-colors text-white placeholder:text-white/30"
        required
      />
      <button
        type="submit"
        className="px-6 py-3 bg-white text-black hover:bg-white/90 transition-colors whitespace-nowrap"
      >
        Request Access
      </button>
    </form>
  );
}
