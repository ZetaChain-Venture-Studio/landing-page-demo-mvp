import { useState } from 'react';

const MODELS = ['gpt-4', 'claude', 'gemini', 'llama'];

const SAMPLE_REQUEST = {
  threadId: 'thread_a7f3d9c2',
  model: 'gpt-4',
  message: 'Explain quantum computing simply',
};

const RESPONSES = {
  'gpt-4': 'Quantum computing uses quantum mechanics principles like superposition and entanglement to process information. Unlike classical bits that are 0 or 1, quantum bits (qubits) can be both simultaneously...',
  'claude': 'Think of quantum computing like this: regular computers are like a person checking one path through a maze at a time. Quantum computers can check multiple paths simultaneously, making them exponentially faster for certain problems...',
  'gemini': 'Quantum computers leverage quantum mechanical phenomena to perform computations. They use qubits which can exist in multiple states at once (superposition), allowing parallel processing of information...',
  'llama': 'Quantum computing is a fundamentally different approach to computation that exploits quantum mechanical properties. Instead of binary bits, it uses qubits that can represent multiple states simultaneously through superposition...',
};

export function ApiDemo() {
  const [selectedModel, setSelectedModel] = useState<string>('gpt-4');
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<string>(RESPONSES['gpt-4']);

  const handleModelChange = (model: string) => {
    setIsLoading(true);
    setSelectedModel(model);
    
    setTimeout(() => {
      setResponse(RESPONSES[model as keyof typeof RESPONSES]);
      setIsLoading(false);
    }, 600);
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Request */}
      <div>
        <div className="text-xs text-white/40 mb-3 font-mono">REQUEST</div>
        <div className="bg-[#111] border border-white/10 rounded-lg overflow-hidden font-mono text-xs">
          <div className="border-b border-white/10 px-4 py-2 text-[10px] text-white/40">
            POST /v1/chat
          </div>
          <div className="p-4">
            <pre className="text-white/70">
{`{
  "threadId": "${SAMPLE_REQUEST.threadId}",
  "model": "`}<span className="text-green-400">{selectedModel}</span>{`",
  "message": "${SAMPLE_REQUEST.message}"
}`}
            </pre>
          </div>
        </div>

        {/* Model selector */}
        <div className="mt-4">
          <div className="text-xs text-white/40 mb-2 font-mono">SWITCH MODEL</div>
          <div className="grid grid-cols-2 gap-2">
            {MODELS.map((model) => (
              <button
                key={model}
                onClick={() => handleModelChange(model)}
                className={`px-4 py-2 text-xs font-mono border transition-colors ${
                  selectedModel === model
                    ? 'bg-white/10 border-white/30 text-white'
                    : 'bg-white/5 border-white/10 text-white/50 hover:border-white/20'
                }`}
              >
                {model}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Response */}
      <div>
        <div className="text-xs text-white/40 mb-3 font-mono">RESPONSE</div>
        <div className="bg-[#111] border border-white/10 rounded-lg overflow-hidden font-mono text-xs">
          <div className="border-b border-white/10 px-4 py-2 text-[10px] text-white/40 flex items-center justify-between">
            <span>200 OK</span>
            {isLoading && (
              <span className="text-green-400">● Streaming...</span>
            )}
          </div>
          <div className="p-4 min-h-[200px]">
            <pre className="text-white/70 whitespace-pre-wrap">
{`{
  "id": "msg_k9d8fj2l",
  "model": "${selectedModel}",
  "threadId": "${SAMPLE_REQUEST.threadId}",
  "content": "${isLoading ? 'Loading...' : response}",
  "contextPreserved": true
}`}
            </pre>
          </div>
        </div>

        <div className="mt-4 p-3 bg-green-400/10 border border-green-400/20 text-xs text-green-400">
          ✓ Context from previous messages maintained across model switch
        </div>
      </div>
    </div>
  );
}
