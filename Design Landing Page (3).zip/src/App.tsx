import { ApiDemo } from './components/ApiDemo';
import { CodeExample } from './components/CodeExample';
import { WaitlistForm } from './components/WaitlistForm';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Hero */}
      <div className="border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-20">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block px-2 py-1 border border-white/20 text-xs mb-6 tracking-widest text-white/60">
                DEVELOPER API
              </div>
              
              <h1 className="text-6xl mb-6 tracking-tight">
                One API for<br />every AI model
              </h1>
              
              <p className="text-xl text-white/50 mb-8 leading-relaxed">
                Switch between GPT-4, Claude, Gemini, and Llama with a single parameter. 
                Context persists. No vendor lock-in.
              </p>
              
              <div className="flex gap-3">
                <button className="px-6 py-3 bg-white text-black hover:bg-white/90 transition-colors">
                  Get API Key
                </button>
                <button className="px-6 py-3 border border-white/20 hover:border-white/40 transition-colors">
                  View Docs
                </button>
              </div>
            </div>

            <div>
              <CodeExample />
            </div>
          </div>
        </div>
      </div>

      {/* API Demo */}
      <div className="border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-20">
          <div className="text-xs uppercase tracking-widest text-white/40 mb-8">
            LIVE API CONSOLE
          </div>
          <ApiDemo />
        </div>
      </div>

      {/* Features */}
      <div className="border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-20">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="text-sm text-white/40 mb-4 font-mono">01</div>
              <h3 className="text-2xl mb-3 tracking-tight">Unified interface</h3>
              <p className="text-white/50 leading-relaxed">
                Same API endpoint. Switch models by changing one parameter. 
                No need to learn different SDKs.
              </p>
              <div className="mt-4 p-3 bg-white/5 border border-white/10 font-mono text-xs text-white/60">
                model: "gpt-4" | "claude" | "gemini"
              </div>
            </div>

            <div>
              <div className="text-sm text-white/40 mb-4 font-mono">02</div>
              <h3 className="text-2xl mb-3 tracking-tight">Context persistence</h3>
              <p className="text-white/50 leading-relaxed">
                Conversation threads maintain full context across model switches. 
                Automatic memory management.
              </p>
              <div className="mt-4 p-3 bg-white/5 border border-white/10 font-mono text-xs text-white/60">
                thread_id: "thread_abc123"
              </div>
            </div>

            <div>
              <div className="text-sm text-white/40 mb-4 font-mono">03</div>
              <h3 className="text-2xl mb-3 tracking-tight">Client-side storage</h3>
              <p className="text-white/50 leading-relaxed">
                Optional browser SDK stores conversations locally. 
                Zero server-side data retention.
              </p>
              <div className="mt-4 p-3 bg-white/5 border border-white/10 font-mono text-xs text-white/60">
                storage: "local" | "cloud"
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing */}
      <div className="border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-20">
          <div className="max-w-3xl mx-auto text-center">
            <div className="text-xs uppercase tracking-widest text-white/40 mb-6">
              SIMPLE PRICING
            </div>
            <div className="text-7xl mb-4">$25</div>
            <p className="text-xl text-white/50 mb-8">
              per month · unlimited requests · all models included
            </p>
            <div className="text-sm text-white/30">
              No per-token charges. No overage fees. No surprises.
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl mb-6 tracking-tight">
            Join the private beta
          </h2>
          <p className="text-white/50 mb-8">
            Limited API keys available for early adopters
          </p>
          <WaitlistForm />
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex justify-between items-center text-sm text-white/20">
            <div>ANUMA</div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white/40 transition-colors">Docs</a>
              <a href="#" className="hover:text-white/40 transition-colors">GitHub</a>
              <a href="#" className="hover:text-white/40 transition-colors">Status</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
