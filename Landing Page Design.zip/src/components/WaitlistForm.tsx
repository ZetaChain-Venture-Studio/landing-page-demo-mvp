import { useState } from 'react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) return;

    setStatus('submitting');
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setStatus('success');
    setEmail('');
    
    // Reset after 3 seconds
    setTimeout(() => setStatus('idle'), 3000);
  };

  return (
    <div className="max-w-3xl">
      {status === 'success' ? (
        <div className="py-6 px-8 border border-black bg-white shadow-[12px_12px_0px_0px_rgba(0,0,0,0.08)]">
          <p className="text-black font-mono text-sm">✓ You're in. Check your email.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-0 border border-black bg-white shadow-[12px_12px_0px_0px_rgba(0,0,0,0.08)] hover:shadow-[16px_16px_0px_0px_rgba(0,0,0,0.12)] transition-all duration-300 group">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              disabled={status === 'submitting'}
              className="flex-1 px-8 py-6 bg-transparent border-none focus:outline-none text-black placeholder-neutral-400 disabled:opacity-50 text-lg"
            />
            <button
              type="submit"
              disabled={status === 'submitting' || !email}
              className="px-12 py-6 bg-black text-white hover:bg-neutral-800 disabled:bg-neutral-200 disabled:text-neutral-400 transition-all duration-300 sm:border-l border-black text-lg tracking-tight"
            >
              {status === 'submitting' ? '...' : 'Join waitlist'}
            </button>
          </div>
          <p className="text-xs text-neutral-400 font-mono px-1">
            500+ waiting for early access
          </p>
        </form>
      )}
    </div>
  );
}