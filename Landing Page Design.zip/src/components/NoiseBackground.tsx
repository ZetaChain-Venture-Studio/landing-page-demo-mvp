import { useEffect, useRef } from 'react';

export function NoiseBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const updateSize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      drawPattern();
    };

    const drawPattern = () => {
      // Clear canvas with stone background
      ctx.fillStyle = '#f5f5f4';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Create fine-grain pixelated noise
      const pixelSize = 3;
      
      for (let x = 0; x < canvas.width; x += pixelSize) {
        for (let y = 0; y < canvas.height; y += pixelSize) {
          // Very subtle, uniform grain
          if (Math.random() < 0.08) {
            const opacity = Math.random() * 0.025;
            ctx.fillStyle = `rgba(0, 0, 0, ${opacity})`;
            ctx.fillRect(x, y, pixelSize, pixelSize);
          }
        }
      }

      // Add occasional larger pixel blocks for texture
      for (let i = 0; i < 25; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const size = 8 + Math.random() * 12;
        const opacity = Math.random() * 0.015;
        
        ctx.fillStyle = `rgba(0, 0, 0, ${opacity})`;
        ctx.fillRect(
          Math.floor(x / 6) * 6,
          Math.floor(y / 6) * 6,
          size,
          size
        );
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);

    return () => {
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ imageRendering: 'pixelated' }}
    />
  );
}