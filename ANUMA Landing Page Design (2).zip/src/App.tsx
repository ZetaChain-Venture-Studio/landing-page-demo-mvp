import { useState } from 'react';
import { InteractiveDemo } from './components/InteractiveDemo';
import { WaitlistModal } from './components/WaitlistModal';

export default function App() {
  const [showWaitlist, setShowWaitlist] = useState(false);

  return (
    <div className="min-h-screen bg-white relative overflow-hidden">
      {/* Floating subtle text hints */}
      <div className="absolute inset-0 pointer-events-none select-none">
        <div className="absolute top-[15%] left-[10%] text-[8vw] opacity-[0.02] rotate-[-5deg]">
          CONTEXT
        </div>
        <div className="absolute bottom-[20%] right-[8%] text-[6vw] opacity-[0.02] rotate-[3deg]">
          PRIVACY
        </div>
        <div className="absolute top-[60%] left-[5%] text-[5vw] opacity-[0.02] rotate-[-2deg]">
          SEAMLESS
        </div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="px-6 md:px-12 py-8 flex justify-between items-center">
          <div className="text-xs tracking-[0.3em] text-black/30">ANUMA</div>
          <button 
            onClick={() => setShowWaitlist(true)}
            className="px-6 py-2 border border-black/20 text-xs tracking-wider hover:bg-black hover:text-white transition-colors"
          >
            JOIN WAITLIST
          </button>
        </header>

        {/* Main content */}
        <div className="flex-1 flex items-center justify-center px-6 py-12">
          <div className="max-w-7xl w-full mx-auto">
            <div className="grid lg:grid-cols-[1fr,1.5fr] gap-16 lg:gap-24 items-center">
              {/* Left - Content */}
              <div className="space-y-8 max-w-xl">
                <div className="space-y-6">
                  <h1 className="text-[clamp(3rem,7vw,5.5rem)] leading-[0.9] tracking-tight">
                    <span className="block text-black">Any model.</span>
                    <span className="block text-black">Same context.</span>
                  </h1>
                </div>

                <div className="space-y-4 text-lg text-black/60 leading-relaxed max-w-md">
                  <p>
                    ANUMA preserves your conversation as you switch between AI models. No repeating yourself. No lost context.
                  </p>
                  <div className="flex flex-wrap gap-x-6 gap-y-2 pt-2 text-sm text-black/40">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-1 bg-black/40 rounded-full" />
                      <span>Try it now →</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right - Interactive Demo */}
              <div className="relative">
                <InteractiveDemo onComplete={() => setShowWaitlist(true)} />
              </div>
            </div>
          </div>
        </div>

        {/* Footer hints */}
        <footer className="px-6 md:px-12 py-8">
          <div className="flex justify-between items-center text-xs text-black/20 tracking-wider">
            <div>EARLY ACCESS</div>
            <div>2025</div>
          </div>
        </footer>
      </div>

      {showWaitlist && <WaitlistModal onClose={() => setShowWaitlist(false)} />}
    </div>
  );
}
