import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TypedMessage } from './components/TypedMessage';
import { ContextPanel } from './components/ContextPanel';

interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
  model?: string;
  id: number;
  highlightName?: boolean;
}

interface ContextData {
  name?: string;
  workingOn?: string;
  needsHelp?: string;
}

export default function App() {
  const [step, setStep] = useState(0); // 0: intro, 1-3: questions, 4: email
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState('');
  const [context, setContext] = useState<ContextData>({});
  const [isTyping, setIsTyping] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [messageIdCounter, setMessageIdCounter] = useState(0);
  const [flashContext, setFlashContext] = useState(false);
  const [showContextPanel, setShowContextPanel] = useState(false);

  // Start the experience
  useEffect(() => {
    // Show first message immediately
    setMessages([{ 
      role: 'system', 
      content: 'Initializing ANUMA...',
      id: 0
    }]);
    setMessageIdCounter(1);
    
    const timer = setTimeout(() => {
      setMessages([{
        role: 'system',
        content: 'Connection established. Context engine ready.',
        id: 1
      }]);
      setMessageIdCounter(2);
      
      setTimeout(() => {
        setStep(1);
        setMessages([{
          role: 'assistant',
          content: "Let's start simple. What's your name?",
          model: 'ANUMA',
          id: 2
        }]);
        setMessageIdCounter(3);
      }, 2000);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleSubmitAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const userMessage = userInput;
    const currentId = messageIdCounter;
    setMessages([{ role: 'user', content: userMessage, id: currentId }]);
    setMessageIdCounter(prev => prev + 1);
    setUserInput('');

    // Show typing indicator
    setIsTyping(true);

    // Generate response based on step
    setTimeout(() => {
      setIsTyping(false);
      const nextId = messageIdCounter + 1;
      setMessageIdCounter(prev => prev + 1);
      
      if (step === 1) {
        // First question answered - add name to context
        setContext({ name: userMessage });
        setShowContextPanel(true);
        
        setTimeout(() => {
          // Flash context when it's used in the response
          setFlashContext(true);
          setMessages([{
            role: 'assistant',
            content: `Nice to meet you, ${userMessage}. What's something you're working on right now?`,
            model: 'GPT-4',
            id: nextId,
            highlightName: true
          }]);
          
          setTimeout(() => setFlashContext(false), 2000);
          setStep(2);
        }, 800);
        
      } else if (step === 2) {
        // Second question answered - add working on to context
        setContext(prev => ({ ...prev, workingOn: userMessage }));
        
        setTimeout(() => {
          setFlashContext(true);
          setMessages([{
            role: 'assistant',
            content: `How can I help you, ${context.name}?`,
            model: 'Claude',
            id: nextId,
            highlightName: true
          }]);
          
          setTimeout(() => setFlashContext(false), 2000);
          setStep(3);
        }, 800);
        
      } else if (step === 3 && !showModelPicker) {
        // Third question answered - add need help to context, then show model picker
        setContext(prev => ({ ...prev, needsHelp: userMessage }));
        
        setTimeout(() => {
          setShowModelPicker(true);
        }, 800);
        
      } else if (step === 3 && selectedModel) {
        // Model selected - show response using all context
        const responses = {
          'GPT-4': `${context.name}, for ${context.workingOn}, I'd start with ${context.needsHelp}. Given your background, you'll want to focus on scalability from day one.`,
          'Claude': `Hi ${context.name}! For ${context.workingOn}, specifically ${context.needsHelp}, I'd recommend a structured approach: 1) Define your core value proposition, 2) Identify key technical challenges, 3) Build an MVP timeline. Want me to elaborate?`,
          'Gemini': `${context.name}, working on ${context.workingOn} is exciting! For ${context.needsHelp}, I can help you with real-time data analysis, multi-modal understanding, or integration strategies. What would be most valuable?`
        };
        
        setFlashContext(true);
        setMessages([{
          role: 'assistant',
          content: responses[selectedModel as keyof typeof responses],
          model: selectedModel,
          id: nextId,
          highlightName: true
        }]);
        
        setTimeout(() => {
          setFlashContext(false);
          const systemId = messageIdCounter + 2;
          setMessageIdCounter(prev => prev + 1);
          setMessages(prev => [...prev, {
            role: 'system',
            content: `See how the context stayed consistent across different AI models? That's ANUMA.`,
            id: systemId
          }]);
          
          setTimeout(() => {
            setStep(4);
          }, 2500);
        }, 2000);
      }
    }, 1200 + Math.random() * 800);
  };

  const handleModelSelect = (model: string) => {
    setSelectedModel(model);
    setShowModelPicker(false);
    const currentId = messageIdCounter;
    setMessages([{
      role: 'user',
      content: `I choose ${model}`,
      id: currentId
    }]);
    setMessageIdCounter(prev => prev + 1);
    
    // Trigger response
    setTimeout(() => {
      handleSubmitAnswer({ preventDefault: () => {} } as React.FormEvent);
    }, 500);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    
    console.log('Waitlist signup:', { email, context });
    const currentId = messageIdCounter;
    setMessages([{
      role: 'system',
      content: `Thanks ${context.name}! We'll reach out to ${email} soon. Get ready to experience AI without limits.`,
      id: currentId
    }]);
    setMessageIdCounter(prev => prev + 1);
    setStep(5);
  };

  return (
    <div className="min-h-screen bg-white text-black flex items-center justify-center p-6 overflow-hidden">
      {/* Animated background - subtle */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(black 1px, transparent 1px), linear-gradient(90deg, black 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="relative z-10 w-full max-w-5xl">
        {/* ANUMA branding - top left */}
        <div className="absolute -top-12 left-0 text-xs tracking-[0.3em] text-black/30">
          ANUMA
        </div>

        <div className="grid lg:grid-cols-[1fr,300px] gap-12 items-start">
          {/* Main conversation area */}
          <div>
            {/* Messages container */}
            <div className="space-y-6 mb-8 min-h-[300px] flex flex-col justify-center">
              <AnimatePresence mode="wait">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.5 }}
                    className={`${
                      message.role === 'user' ? 'flex justify-end' :
                      message.role === 'system' ? 'flex justify-center' :
                      'flex justify-start'
                    }`}
                  >
                    <div className={`max-w-[85%] ${
                      message.role === 'user' ? 'text-right' :
                      message.role === 'system' ? 'text-center' :
                      'text-left'
                    }`}>
                      {message.model && message.role === 'assistant' && (
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.2 }}
                          className="text-[10px] tracking-widest text-black/40 mb-2 uppercase"
                        >
                          {message.model}
                        </motion.div>
                      )}
                      <div className={`inline-block ${
                        message.role === 'user' 
                          ? 'bg-black text-white px-6 py-4' 
                          : message.role === 'system'
                          ? 'text-black/50 text-sm px-4 py-2 border border-black/10'
                          : 'text-black/80 px-6 py-4 bg-black/[0.02]'
                      }`}>
                        {message.role === 'system' && step === 0 ? (
                          <TypedMessage text={message.content} speed={50} />
                        ) : (
                          <p className={message.role === 'system' ? 'text-sm' : 'text-lg'}>
                            {message.highlightName && context.name ? (
                              <>
                                {message.content.split(context.name).map((part, i, arr) => (
                                  <span key={i}>
                                    {part}
                                    {i < arr.length - 1 && (
                                      <motion.span
                                        animate={{ 
                                          fontWeight: flashContext ? 700 : 400,
                                        }}
                                        transition={{ duration: 0.3 }}
                                      >
                                        {context.name}
                                      </motion.span>
                                    )}
                                  </span>
                                ))}
                              </>
                            ) : (
                              message.content
                            )}
                          </p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Typing indicator */}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="flex gap-1.5 px-6 py-4">
                    <motion.div
                      className="w-2 h-2 bg-black/40 rounded-full"
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                    />
                    <motion.div
                      className="w-2 h-2 bg-black/40 rounded-full"
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                    />
                    <motion.div
                      className="w-2 h-2 bg-black/40 rounded-full"
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                    />
                  </div>
                </motion.div>
              )}
            </div>

            {/* Model picker */}
            {showModelPicker && step === 3 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-8"
              >
                <div className="text-center mb-6">
                  <p className="text-black/60 text-sm">Choose your AI model:</p>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {['GPT-4', 'Claude', 'Gemini'].map((model) => (
                    <motion.button
                      key={model}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleModelSelect(model)}
                      className="p-6 border-2 border-black/10 hover:border-black/40 hover:bg-black/[0.02] transition-all"
                    >
                      <div className="text-lg tracking-wide">{model}</div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Input area */}
            {step >= 1 && step <= 3 && !showModelPicker && (
              <motion.form
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                onSubmit={handleSubmitAnswer}
                className="relative"
              >
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder="Type your answer..."
                  autoFocus
                  className="w-full bg-transparent border-b-2 border-black/10 text-black text-xl py-4 px-0 placeholder:text-black/30 focus:outline-none focus:border-black/60 transition-colors"
                />
                <motion.button
                  type="submit"
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-black/40 hover:text-black transition-colors"
                  whileHover={{ x: 5 }}
                >
                  →
                </motion.button>
              </motion.form>
            )}

            {/* Email signup */}
            {step === 4 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-12 text-center space-y-6"
              >
                <div>
                  <h2 className="text-4xl mb-3 tracking-tight">Experience this yourself.</h2>
                  <p className="text-black/60">Join the waitlist for early access.</p>
                </div>
                
                <form onSubmit={handleEmailSubmit} className="max-w-md mx-auto space-y-4">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    required
                    autoFocus
                    className="w-full bg-transparent border-b-2 border-black/10 text-black text-xl py-4 px-0 placeholder:text-black/30 focus:outline-none focus:border-black/60 transition-colors text-center"
                  />
                  
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-black text-white py-4 text-lg tracking-wide hover:bg-black/90 transition-colors"
                  >
                    Join waitlist
                  </motion.button>

                  <div className="flex justify-center gap-6 text-xs text-black/40 pt-2">
                    <span>No subscriptions</span>
                    <span>•</span>
                    <span>Privacy first</span>
                    <span>•</span>
                    <span>Local storage</span>
                  </div>
                </form>
              </motion.div>
            )}

            {/* Success state */}
            {step === 5 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 bg-black rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <span className="text-white text-3xl">✓</span>
                </motion.div>
                <h3 className="text-3xl mb-3 tracking-tight">You're in, {context.name}.</h3>
                <p className="text-black/60">We'll be in touch soon.</p>
              </motion.div>
            )}
          </div>

          {/* Context Panel - Right side */}
          {showContextPanel && step < 4 && (
            <ContextPanel context={context} flash={flashContext} />
          )}
        </div>
      </div>
    </div>
  );
}