import { motion, AnimatePresence } from 'motion/react';

interface ContextData {
  name?: string;
  workingOn?: string;
  needsHelp?: string;
}

interface Props {
  context: ContextData;
  flash: boolean;
}

export function ContextPanel({ context, flash }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ 
        opacity: 1, 
        x: 0,
      }}
      className="sticky top-6"
    >
      <motion.div
        animate={{
          borderColor: flash ? 'rgb(0, 0, 0)' : 'rgba(0, 0, 0, 0.1)',
          borderWidth: flash ? '3px' : '2px',
        }}
        transition={{ duration: 0.3 }}
        className="border-2 border-black/10 p-6 bg-white"
      >
        <div className="text-[10px] tracking-[0.3em] text-black/40 mb-4">
          SHARED CONTEXT
        </div>
        
        <div className="space-y-4">
          <AnimatePresence>
            {context.name && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden"
              >
                <div className="text-xs text-black/50 mb-1 tracking-wide">NAME</div>
                <motion.div
                  initial={{ x: -10, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-lg text-black"
                >
                  {context.name}
                </motion.div>
              </motion.div>
            )}

            {context.workingOn && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden pt-2 border-t border-black/5"
              >
                <div className="text-xs text-black/50 mb-1 tracking-wide">WORKING ON</div>
                <motion.div
                  initial={{ x: -10, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-lg text-black"
                >
                  {context.workingOn}
                </motion.div>
              </motion.div>
            )}

            {context.needsHelp && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden pt-2 border-t border-black/5"
              >
                <div className="text-xs text-black/50 mb-1 tracking-wide">NEEDS HELP WITH</div>
                <motion.div
                  initial={{ x: -10, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-lg text-black"
                >
                  {context.needsHelp}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Connection indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 pt-4 border-t border-black/5"
        >
          <div className="flex items-center gap-2">
            <motion.div
              animate={{ 
                backgroundColor: flash ? 'rgb(34, 197, 94)' : 'rgba(34, 197, 94, 0.5)',
                scale: flash ? [1, 1.2, 1] : 1
              }}
              transition={{ duration: 0.3 }}
              className="w-2 h-2 bg-green-500 rounded-full"
            />
            <span className="text-xs text-black/40">Context preserved</span>
          </div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
