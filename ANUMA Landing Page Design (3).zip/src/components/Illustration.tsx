import { motion } from 'motion/react';

export function Illustration() {
  return (
    <div className="relative w-full aspect-square max-w-md mx-auto">
      {/* Background circle */}
      <div className="absolute inset-0 bg-[#E07856] rounded-full opacity-10"></div>
      
      {/* Central hub */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        {/* Center circle */}
        <div className="w-full h-full rounded-full bg-white border-2 border-[#1A1A1A] flex items-center justify-center relative overflow-hidden">
          <span className="text-[#1A1A1A] text-sm relative z-10">ANUMA</span>
          
          {/* Subtle scan line */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-b from-transparent via-[#E07856]/10 to-transparent"
            animate={{
              y: ['-100%', '100%'],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "linear",
            }}
          />
        </div>

        {/* Pulsing ring */}
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-[#E07856]"
          animate={{
            scale: [1, 1.3],
            opacity: [0.5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeOut",
          }}
        />
      </motion.div>

      {/* User node */}
      <motion.div
        className="absolute top-1/2 left-8 -translate-y-1/2"
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        <div className="relative">
          {/* Simple head illustration */}
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <circle cx="40" cy="40" r="38" stroke="#1A1A1A" strokeWidth="2" fill="white" />
            <circle cx="40" cy="35" r="20" stroke="#1A1A1A" strokeWidth="2" fill="none" />
            <path d="M 25 50 Q 40 60 55 50" stroke="#1A1A1A" strokeWidth="2" fill="none" />
          </svg>
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs text-[#5A5A5A] whitespace-nowrap">
            You
          </div>

          {/* Connection line */}
          <motion.div
            className="absolute left-[80px] top-[40px] w-[60px] md:w-[80px] h-0.5 bg-[#E07856]"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            style={{ transformOrigin: 'left' }}
          />

          {/* Data flow particle */}
          <motion.div
            className="absolute left-[80px] top-[38px] w-2 h-2 bg-[#E07856] rounded-full"
            animate={{
              x: [0, 60, 80],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 1,
              ease: "easeInOut",
            }}
          />
        </div>
      </motion.div>

      {/* AI Model nodes */}
      {[
        { name: 'GPT', angle: -40, delay: 0.5, icon: 'G' },
        { name: 'Claude', angle: 0, delay: 0.6, icon: 'C' },
        { name: 'Gemini', angle: 40, delay: 0.7, icon: 'G' },
      ].map((model, i) => {
        const radius = 140;
        const x = Math.cos((model.angle * Math.PI) / 180) * radius;
        const y = Math.sin((model.angle * Math.PI) / 180) * radius;

        return (
          <motion.div
            key={model.name}
            className="absolute top-1/2 left-1/2"
            style={{
              transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: model.delay }}
          >
            <div className="relative">
              {/* Simple geometric icon for each model */}
              <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
                {i === 0 && (
                  <>
                    <rect x="10" y="10" width="40" height="40" rx="8" stroke="#1A1A1A" strokeWidth="2" fill="white" />
                    <rect x="20" y="20" width="20" height="20" fill="#E07856" opacity="0.3" />
                  </>
                )}
                {i === 1 && (
                  <>
                    <circle cx="30" cy="30" r="24" stroke="#1A1A1A" strokeWidth="2" fill="white" />
                    <circle cx="30" cy="30" r="12" fill="#E07856" opacity="0.3" />
                  </>
                )}
                {i === 2 && (
                  <>
                    <polygon points="30,8 52,44 8,44" stroke="#1A1A1A" strokeWidth="2" fill="white" />
                    <polygon points="30,20 40,38 20,38" fill="#E07856" opacity="0.3" />
                  </>
                )}
              </svg>
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-xs text-[#5A5A5A] whitespace-nowrap">
                {model.name}
              </div>

              {/* Connection line to center */}
              <motion.div
                className="absolute right-[60px] top-[30px] w-[60px] md:w-[80px] h-0.5 bg-[#E07856] origin-right"
                style={{
                  transform: `rotate(${-model.angle}deg)`,
                }}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.5, delay: 1 + i * 0.1 }}
              />

              {/* Bidirectional flow particles */}
              <motion.div
                className="absolute right-[60px] top-[28px] w-2 h-2 bg-[#E07856] rounded-full"
                style={{
                  transformOrigin: 'center',
                }}
                animate={{
                  x: [0, -60, -80],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: 2 + i * 0.3,
                  repeatDelay: 2,
                  ease: "easeInOut",
                }}
              />

              <motion.div
                className="absolute right-[140px] top-[28px] w-1.5 h-1.5 bg-[#1A1A1A] rounded-full opacity-50"
                animate={{
                  x: [0, 60, 80],
                  opacity: [0, 0.5, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: 3.5 + i * 0.3,
                  repeatDelay: 2,
                  ease: "easeInOut",
                }}
              />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
