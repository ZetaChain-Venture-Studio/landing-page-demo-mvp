import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  model?: string;
}

const demoFlow = {
  prompts: [
    "Explain quantum computing in simple terms",
    "How does that relate to cryptography?",
    "Which is better for this: GPT or Claude?"
  ],
  responses: {
    GPT: [
      "Quantum computing uses quantum bits (qubits) that can exist in multiple states simultaneously, unlike classical bits that are either 0 or 1. This allows quantum computers to process certain calculations exponentially faster.",
      "Quantum computers could potentially break current encryption methods because they can factor large numbers much faster than classical computers. This threatens RSA encryption, which relies on the difficulty of factoring.",
      "For cryptography explanations, I'd recommend Claude - it tends to provide more structured security analysis."
    ],
    Claude: [
      "Think of quantum computing like this: regular computers use bits like light switches (on/off). Quantum computers use qubits that can be both on AND off at the same time, like a coin spinning in the air before it lands.",
      "Building on what we discussed about quantum computing: Current encryption relies on math problems that take classical computers centuries to solve. Quantum computers could solve these in hours, which is why we're developing 'quantum-resistant' encryption.",
      "I appreciate the question! While GPT and I approach things differently, for understanding security implications, I focus more on practical risks and mitigation strategies."
    ],
    Gemini: [
      "Quantum computing harnesses quantum mechanics principles - superposition and entanglement. Qubits can represent 0, 1, or both simultaneously (superposition), enabling parallel processing at an unprecedented scale.",
      "The connection is critical: Shor's algorithm, running on a quantum computer, could break RSA-2048 encryption in days versus billions of years on classical systems. Post-quantum cryptography is now a priority.",
      "Each model has strengths. GPT excels at creative explanations, Claude at detailed analysis, and I integrate multi-modal understanding with real-time data."
    ]
  }
};

interface Props {
  onComplete: () => void;
}

export function InteractiveDemo({ onComplete }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentModel, setCurrentModel] = useState<'GPT' | 'Claude' | 'Gemini'>('GPT');
  const [step, setStep] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [showModelSwitch, setShowModelSwitch] = useState(false);

  const models = ['GPT', 'Claude', 'Gemini'] as const;

  const sendMessage = (prompt: string, model: typeof currentModel) => {
    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: prompt }]);
    
    // Simulate typing
    setIsTyping(true);
    
    setTimeout(() => {
      setIsTyping(false);
      const response = demoFlow.responses[model][step];
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: response,
        model: model
      }]);
      
      // Show model switcher after first response
      if (step === 0) {
        setTimeout(() => setShowModelSwitch(true), 1000);
      }

      // Progress to next step or complete
      if (step < demoFlow.prompts.length - 1) {
        setTimeout(() => setStep(step + 1), 2000);
      } else {
        setTimeout(() => onComplete(), 3000);
      }
    }, 1500);
  };

  useEffect(() => {
    if (step < demoFlow.prompts.length) {
      const timer = setTimeout(() => {
        sendMessage(demoFlow.prompts[step], currentModel);
      }, step === 0 ? 1000 : 1500);
      
      return () => clearTimeout(timer);
    }
  }, [step, currentModel]);

  const switchModel = (model: typeof currentModel) => {
    setCurrentModel(model);
    setShowModelSwitch(false);
  };

  return (
    <div className="relative">
      {/* Demo label */}
      <div className="mb-4 flex items-center gap-2">
        <div className="text-xs tracking-wider text-black/40">LIVE DEMO</div>
        <div className="flex-1 h-px bg-black/10" />
        <motion.div
          className="w-2 h-2 bg-black rounded-full"
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>

      {/* Chat interface */}
      <div className="bg-white border-2 border-black/10 h-[500px] flex flex-col">
        {/* Model selector bar */}
        <div className="border-b border-black/10 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-xs tracking-wider text-black/40">CURRENT MODEL:</div>
            <div className="text-sm tracking-wide">{currentModel}</div>
          </div>
          
          {showModelSwitch && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-xs px-3 py-1 border border-black/20 hover:bg-black hover:text-white transition-colors"
              onClick={() => {
                const nextModel = models[(models.indexOf(currentModel) + 1) % models.length];
                switchModel(nextModel);
              }}
            >
              SWITCH MODEL
            </motion.button>
          )}
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <AnimatePresence mode="popLayout">
            {messages.map((message, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] ${message.role === 'user' ? 'text-right' : 'text-left'}`}>
                  {message.role === 'assistant' && message.model && (
                    <div className="text-[10px] tracking-wider text-black/30 mb-1">
                      {message.model}
                    </div>
                  )}
                  <div className={`inline-block p-4 ${
                    message.role === 'user' 
                      ? 'bg-black text-white' 
                      : 'bg-black/5 text-black'
                  }`}>
                    <p className="text-sm leading-relaxed">{message.content}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="bg-black/5 p-4 rounded">
                <div className="flex gap-1">
                  <motion.div
                    className="w-2 h-2 bg-black/40 rounded-full"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-black/40 rounded-full"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-black/40 rounded-full"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                  />
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Context preservation indicator */}
        {messages.length > 2 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="border-t border-black/10 p-3 bg-black/5"
          >
            <div className="flex items-center gap-2 text-xs text-black/60">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
              <span>Context preserved across {messages.filter(m => m.role === 'assistant').length} responses</span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Hint text */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="mt-4 text-xs text-black/30 text-center"
      >
        Watch as the conversation flows across different AI models
      </motion.div>
    </div>
  );
}
