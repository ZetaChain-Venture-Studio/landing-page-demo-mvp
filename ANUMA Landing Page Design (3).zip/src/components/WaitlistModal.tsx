import { useState } from 'react';
import { motion } from 'motion/react';

interface Props {
  onClose: () => void;
}

export function WaitlistModal({ onClose }: Props) {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [focused, setFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Email submitted:', email);
      setSubmitted(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white p-12 max-w-md w-full relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-black/40 hover:text-black text-2xl leading-none"
        >
          ×
        </button>

        {!submitted ? (
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl tracking-tight mb-2">Join the waitlist</h2>
              <p className="text-black/60">Be among the first to experience ANUMA.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative group">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onFocus={() => setFocused(true)}
                  onBlur={() => setFocused(false)}
                  placeholder="your@email.com"
                  required
                  className="w-full px-0 py-4 bg-transparent border-b-2 border-black/10 text-black text-lg placeholder:text-black/20 focus:outline-none focus:border-black transition-colors"
                />
                <div 
                  className="absolute bottom-0 left-0 h-0.5 bg-black transition-all duration-300"
                  style={{ width: focused ? '100%' : '0%' }}
                />
              </div>
              
              <button
                type="submit"
                className="w-full group relative px-12 py-4 bg-black text-white overflow-hidden"
              >
                <span className="relative z-10">Join now</span>
                <div className="absolute inset-0 bg-black/80 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              </button>
            </form>

            <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-black/40">
              <div className="flex items-center gap-2">
                <div className="w-1 h-1 bg-black/40 rounded-full" />
                <span>No subscriptions</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1 h-1 bg-black/40 rounded-full" />
                <span>Privacy first</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1 h-1 bg-black/40 rounded-full" />
                <span>Early access</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="py-12 text-center space-y-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 bg-black rounded-full flex items-center justify-center mx-auto"
            >
              <span className="text-white text-2xl">✓</span>
            </motion.div>
            <div>
              <h3 className="text-2xl tracking-tight mb-2">You're in.</h3>
              <p className="text-black/60">We'll reach out soon.</p>
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
