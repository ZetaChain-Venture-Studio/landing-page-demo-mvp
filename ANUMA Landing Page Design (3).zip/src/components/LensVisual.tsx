import { motion } from 'motion/react';

export function LensVisual() {
  return (
    <div className="relative w-full aspect-square max-w-2xl mx-auto">
      {/* Models on the left - scattered */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-8 space-y-8">
        {['GPT-4', 'Claude', 'Gemini', 'Llama'].map((model, i) => (
          <motion.div
            key={model}
            className="relative"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
          >
            <div className="text-xs tracking-wider text-black/20 relative">
              <span className="absolute -left-8 top-1/2 -translate-y-1/2 w-6 h-px bg-black/10" />
              {model}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Central lens/portal - ANUMA */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.3 }}
      >
        {/* Outer ring */}
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-black/30"
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          {/* Tick marks */}
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-4 bg-black/30 origin-bottom"
              style={{
                transform: `translateX(-50%) rotate(${i * 30}deg)`,
                transformOrigin: `50% 128px`,
              }}
            />
          ))}
        </motion.div>

        {/* Middle ring */}
        <motion.div
          className="absolute inset-8 rounded-full border border-black/20"
          animate={{
            rotate: -360,
          }}
          transition={{
            duration: 40,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        {/* Inner circle */}
        <div className="absolute inset-12 rounded-full bg-gradient-to-br from-black/5 to-transparent backdrop-blur-sm border border-black/10 flex items-center justify-center">
          <div className="text-center">
            <motion.div
              className="text-2xl tracking-[0.2em] text-black"
              animate={{
                opacity: [1, 0.6, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              ANUMA
            </motion.div>
          </div>
        </div>

        {/* Scanning effect */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: 'conic-gradient(from 0deg, transparent 0deg, transparent 340deg, rgba(0,0,0,0.1) 350deg, transparent 360deg)',
          }}
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        {/* Glowing dots */}
        {[0, 90, 180, 270].map((angle, i) => (
          <motion.div
            key={angle}
            className="absolute top-1/2 left-1/2 w-2 h-2 bg-black rounded-full"
            style={{
              transform: `translate(-50%, -50%) rotate(${angle}deg) translateX(120px)`,
            }}
            animate={{
              opacity: [0.2, 1, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.5,
            }}
          />
        ))}
      </motion.div>

      {/* YOU on the right */}
      <motion.div
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-8"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
      >
        <div className="text-xl tracking-wider text-black relative">
          <span className="absolute -right-8 top-1/2 -translate-y-1/2 w-6 h-px bg-black/20" />
          YOU
        </div>
      </motion.div>

      {/* Connection lines */}
      {/* Left side lines going into ANUMA */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {[0, 1, 2, 3].map((i) => {
          const startY = 50 + (i - 1.5) * 20;
          return (
            <motion.line
              key={`line-left-${i}`}
              x1="15%"
              y1={`${startY}%`}
              x2="50%"
              y2="50%"
              stroke="black"
              strokeWidth="1"
              opacity="0.1"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 0.8 + i * 0.1 }}
            />
          );
        })}
        
        {/* Right side line from ANUMA to YOU */}
        <motion.line
          x1="50%"
          y1="50%"
          x2="85%"
          y2="50%"
          stroke="black"
          strokeWidth="2"
          opacity="0.3"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
        />

        {/* Data flow particles */}
        {[0, 1, 2, 3].map((i) => {
          const startY = 50 + (i - 1.5) * 20;
          return (
            <motion.circle
              key={`particle-${i}`}
              r="3"
              fill="black"
              opacity="0.4"
              animate={{
                cx: ['15%', '50%'],
                cy: [`${startY}%`, '50%'],
                opacity: [0, 0.4, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: 2 + i * 0.4,
                repeatDelay: 1,
              }}
            />
          );
        })}

        {/* Output particle */}
        <motion.circle
          r="4"
          fill="black"
          opacity="0.6"
          animate={{
            cx: ['50%', '85%'],
            cy: ['50%', '50%'],
            opacity: [0, 0.6, 0],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            delay: 3,
            repeatDelay: 2,
          }}
        />
      </svg>
    </div>
  );
}
