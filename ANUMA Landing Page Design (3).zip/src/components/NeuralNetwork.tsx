import { motion } from 'motion/react';

export function NeuralNetwork() {
  return (
    <div className="relative w-full max-w-3xl mx-auto h-64 flex items-center justify-center">
      {/* Center node - ANUMA */}
      <motion.div
        className="relative z-20"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        {/* Glowing aura */}
        <motion.div
          className="absolute inset-0 w-32 h-32 -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.1, 0.3],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <div className="w-full h-full rounded-full bg-white blur-xl"></div>
        </motion.div>

        {/* Main circle */}
        <div className="relative w-24 h-24 rounded-full bg-white flex items-center justify-center">
          <span className="text-black text-sm">ANUMA</span>
        </div>
      </motion.div>

      {/* User node - left */}
      <motion.div
        className="absolute left-8 md:left-20"
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.3 }}
      >
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
            <span className="text-white/70 text-xs">You</span>
          </div>
          
          {/* Connection line */}
          <svg className="absolute left-16 top-8 w-20 md:w-40 h-2" preserveAspectRatio="none" viewBox="0 0 160 2">
            <motion.line
              x1="0"
              y1="1"
              x2="160"
              y2="1"
              stroke="url(#gradient-to-center)"
              strokeWidth="2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1, delay: 0.8 }}
            />
            <defs>
              <linearGradient id="gradient-to-center" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.1)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.5)" />
              </linearGradient>
            </defs>
          </svg>

          {/* Flowing particle */}
          <motion.div
            className="absolute left-16 top-7 w-1.5 h-1.5 bg-white rounded-full"
            animate={{
              x: [0, 160],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 1,
              ease: "easeInOut",
            }}
          />
        </div>
      </motion.div>

      {/* AI Model nodes - right side in arc */}
      {[
        { name: 'GPT', angle: -30, delay: 0.4 },
        { name: 'Claude', angle: 0, delay: 0.5 },
        { name: 'Gemini', angle: 30, delay: 0.6 },
      ].map((model, i) => {
        const radius = 180;
        const x = Math.cos((model.angle * Math.PI) / 180) * radius;
        const y = Math.sin((model.angle * Math.PI) / 180) * radius;

        return (
          <motion.div
            key={model.name}
            className="absolute"
            style={{
              right: `${-x}px`,
              top: `calc(50% + ${y}px)`,
              transform: 'translate(50%, -50%)',
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: model.delay }}
          >
            <div className="relative">
              <motion.div
                className="w-14 h-14 rounded-full bg-white/5 backdrop-blur-sm border border-white/20 flex items-center justify-center"
                animate={{
                  borderColor: ['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.4)', 'rgba(255,255,255,0.2)'],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.3,
                }}
              >
                <span className="text-white/70 text-[10px]">{model.name}</span>
              </motion.div>

              {/* Connection line to center */}
              <svg
                className="absolute right-14 top-7 h-2"
                style={{ width: `${radius - 50}px` }}
                preserveAspectRatio="none"
                viewBox={`0 0 ${radius - 50} 2`}
              >
                <motion.line
                  x1={radius - 50}
                  y1="1"
                  x2="0"
                  y2="1"
                  stroke="url(#gradient-from-center)"
                  strokeWidth="2"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1, delay: 1 + i * 0.1 }}
                />
                <defs>
                  <linearGradient id="gradient-from-center" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="rgba(255,255,255,0.5)" />
                    <stop offset="100%" stopColor="rgba(255,255,255,0.1)" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Flowing particles both ways */}
              <motion.div
                className="absolute right-14 top-6 w-1.5 h-1.5 bg-white rounded-full"
                animate={{
                  x: [0, -(radius - 50)],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: 2.5 + i * 0.3,
                  repeatDelay: 2,
                  ease: "easeInOut",
                }}
              />
              <motion.div
                className="absolute right-14 top-6 w-1 h-1 bg-white/60 rounded-full"
                animate={{
                  x: [-(radius - 50), 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: 4 + i * 0.3,
                  repeatDelay: 2.5,
                  ease: "easeInOut",
                }}
              />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
