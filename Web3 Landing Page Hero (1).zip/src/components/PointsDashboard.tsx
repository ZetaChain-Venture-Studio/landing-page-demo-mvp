import { useState } from 'react';
import { motion } from 'motion/react';
import { Twitter, MessageCircle, Share2, CheckCircle, Sparkles, Trophy, Zap } from 'lucide-react';
import nftCardImage from 'figma:asset/8c4b49c823cdaa956375251fd5359f71041c425c.png';

interface Task {
  id: string;
  title: string;
  description: string;
  points: number;
  icon: typeof Twitter;
  completed: boolean;
  action: string;
}

export function PointsDashboard({ email }: { email: string }) {
  const [totalPoints, setTotalPoints] = useState(100); // Starting bonus
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Follow on Twitter',
      description: 'Follow @PopAI on Twitter for updates',
      points: 50,
      icon: Twitter,
      completed: false,
      action: 'Follow'
    },
    {
      id: '2',
      title: 'Join Discord',
      description: 'Join our Discord community',
      points: 50,
      icon: MessageCircle,
      completed: false,
      action: 'Join'
    },
    {
      id: '3',
      title: 'Share on Twitter',
      description: 'Tweet about Pop AI with #PopAI',
      points: 75,
      icon: Share2,
      completed: false,
      action: 'Tweet'
    },
    {
      id: '4',
      title: 'Refer a Friend',
      description: 'Invite friends to join the waitlist',
      points: 100,
      icon: Zap,
      completed: false,
      action: 'Share'
    },
    {
      id: '5',
      title: 'Complete Profile',
      description: 'Add your bio and interests',
      points: 25,
      icon: Sparkles,
      completed: false,
      action: 'Complete'
    },
  ]);

  const handleCompleteTask = (taskId: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, completed: true } : task
      )
    );
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      setTotalPoints(prev => prev + task.points);
    }
  };

  const completedTasksCount = tasks.filter(t => t.completed).length;
  const rank = Math.ceil(12847 / (1 + totalPoints / 100));

  return (
    <div className="relative min-h-screen bg-black overflow-hidden font-['Space_Grotesk']">
      {/* Film Grain */}
      <div className="absolute inset-0 opacity-[0.15] mix-blend-overlay pointer-events-none">
        <svg className="w-full h-full">
          <filter id="noise2">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" stitchTiles="stitch"/>
          </filter>
          <rect width="100%" height="100%" filter="url(#noise2)" />
        </svg>
      </div>

      {/* Background Glow */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-violet-600/20 rounded-full blur-[120px]"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute bottom-0 left-1/4 w-[500px] h-[500px] bg-cyan-500/20 rounded-full blur-[100px]"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 px-6 py-8 border-b border-white/5">
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <motion.div 
              className="relative w-9 h-9"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 rounded-lg blur-sm" />
              <div className="absolute inset-[2px] bg-black rounded-lg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            </motion.div>
            <span className="text-xl text-white tracking-[0.02em] font-[500] uppercase">Pop AI</span>
          </motion.div>
          
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm">
              <span className="text-sm text-white/60 font-[350]">{email}</span>
            </div>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Page Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12"
          >
            <h1 className="text-5xl md:text-6xl tracking-[-0.02em] mb-4 font-[600]">
              <span className="bg-gradient-to-r from-violet-300 via-fuchsia-300 to-cyan-300 bg-clip-text text-transparent">
                Start Earning Points
              </span>
            </h1>
            <p className="text-white/40 text-lg font-[350]">
              Complete tasks to increase your rank and unlock exclusive benefits
            </p>
          </motion.div>

          {/* Two Column Layout */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Left: Tasks List */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-4"
            >
              {tasks.map((task, index) => {
                const Icon = task.icon;
                return (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                    className="relative group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 to-cyan-500/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="relative p-6 bg-white/[0.02] backdrop-blur-sm border border-white/10 rounded-2xl hover:border-white/20 transition-all">
                      <div className="flex items-start gap-4">
                        <div className={`p-3 rounded-xl ${task.completed ? 'bg-emerald-500/20' : 'bg-white/5'}`}>
                          <Icon className={`w-5 h-5 ${task.completed ? 'text-emerald-400' : 'text-white/60'}`} />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-white font-[450] tracking-tight">{task.title}</h3>
                            <span className="text-violet-400 text-sm font-[500]">+{task.points} pts</span>
                          </div>
                          <p className="text-white/40 text-sm font-[350] mb-4">{task.description}</p>
                          
                          {task.completed ? (
                            <div className="flex items-center gap-2 text-emerald-400 text-sm font-[450]">
                              <CheckCircle className="w-4 h-4" />
                              <span>Completed</span>
                            </div>
                          ) : (
                            <motion.button
                              onClick={() => handleCompleteTask(task.id)}
                              className="px-4 py-2 bg-gradient-to-r from-violet-600 to-cyan-600 rounded-lg text-sm text-white font-[500] uppercase tracking-wider hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] transition-all"
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              {task.action}
                            </motion.button>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>

            {/* Right: NFT Card with Score Overlay */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="lg:sticky lg:top-8 h-fit space-y-6"
            >
              {/* NFT Card Image with Score Overlay */}
              <div className="relative">
                {/* Glow effect */}
                <div className="absolute -inset-4 bg-gradient-to-br from-violet-500/40 via-fuchsia-500/40 to-cyan-500/40 rounded-3xl blur-3xl" />
                
                {/* NFT Image */}
                <div className="relative">
                  <img 
                    src={nftCardImage} 
                    alt="Genesis Member NFT Card" 
                    className="w-full h-auto rounded-2xl"
                  />
                  
                  {/* Score Overlay - positioned where "YOUR SCORE:" text is */}
                  <div className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                    <motion.div 
                      className="text-6xl md:text-7xl font-[700] tracking-tight text-white drop-shadow-[0_0_20px_rgba(139,92,246,0.8)]"
                      key={totalPoints}
                      initial={{ scale: 1.3, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                    >
                      {totalPoints}
                    </motion.div>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4">
                <motion.div 
                  className="relative group"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-violet-500/20 to-transparent rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative p-6 bg-white/[0.03] backdrop-blur-sm border border-white/10 rounded-xl">
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-2 font-[350]">Rank</div>
                    <div className="text-3xl text-white font-[500]">#{rank.toLocaleString()}</div>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="relative group"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-l from-cyan-500/20 to-transparent rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative p-6 bg-white/[0.03] backdrop-blur-sm border border-white/10 rounded-xl">
                    <div className="text-white/40 text-xs uppercase tracking-wider mb-2 font-[350]">Tasks</div>
                    <div className="text-3xl text-white font-[500]">{completedTasksCount}/{tasks.length}</div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
