import { useState } from 'react';
import { BlueprintBackground } from './components/BlueprintBackground';
import { TechnicalDiagram } from './components/TechnicalDiagram';

export default function App() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // Handle waitlist signup
      console.log('Email submitted:', email);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#E5DDD5] overflow-hidden">
      <BlueprintBackground />
      
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-12">
        {/* Technical annotations - subtle hints */}
        <div className="absolute top-8 right-8 text-right text-xs font-mono text-[#3a3a3a] opacity-40 hidden md:block">
          <div>privacy: local</div>
          <div>context: persistent</div>
          <div>models: multiple</div>
          <div>subscription: none</div>
        </div>

        <div className="absolute bottom-8 left-8 text-left text-xs font-mono text-[#3a3a3a] opacity-40 hidden md:block">
          <div>─── memory storage</div>
          <div>─── context bridge</div>
          <div>─── model selector</div>
        </div>

        {/* Main content */}
        <div className="max-w-4xl mx-auto text-center space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <h1 className="text-6xl md:text-8xl tracking-tight text-[#2a2a2a]">
              ANUMA
            </h1>
            <div className="h-px w-32 bg-[#3a3a3a] mx-auto opacity-30"></div>
          </div>

          {/* Subheader */}
          <p className="text-xl md:text-2xl text-[#4a4a4a] max-w-2xl mx-auto leading-relaxed">
            Your intelligence layer.
            <br />
            One interface. Every model. Your data.
          </p>

          {/* Technical diagram */}
          <div className="py-8">
            <TechnicalDiagram />
          </div>

          {/* Waitlist form */}
          <div className="max-w-md mx-auto">
            <form onSubmit={handleSubmit} className="relative">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="enter@email.address"
                  required
                  className="w-full px-6 py-4 bg-transparent border border-[#3a3a3a] text-[#2a2a2a] placeholder:text-[#8a8a8a] font-mono text-sm focus:outline-none focus:border-[#2a2a2a] transition-colors"
                  disabled={submitted}
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-6 py-2 bg-[#2a2a2a] text-[#E5DDD5] font-mono text-sm hover:bg-[#1a1a1a] transition-colors disabled:opacity-50"
                  disabled={submitted}
                >
                  {submitted ? 'JOINED' : 'JOIN'}
                </button>
              </div>
            </form>

            {submitted && (
              <p className="mt-4 text-sm font-mono text-[#4a4a4a]">
                ✓ You're on the list
              </p>
            )}

            <p className="mt-4 text-xs font-mono text-[#6a6a6a] opacity-60">
              Early access • Limited spots
            </p>
          </div>
        </div>

        {/* Blueprint grid reference marks */}
        <div className="absolute top-4 left-4 text-xs font-mono text-[#3a3a3a] opacity-20">
          A1
        </div>
        <div className="absolute top-4 right-4 text-xs font-mono text-[#3a3a3a] opacity-20">
          K1
        </div>
        <div className="absolute bottom-4 left-4 text-xs font-mono text-[#3a3a3a] opacity-20">
          A24
        </div>
        <div className="absolute bottom-4 right-4 text-xs font-mono text-[#3a3a3a] opacity-20">
          K24
        </div>
      </div>
    </div>
  );
}
