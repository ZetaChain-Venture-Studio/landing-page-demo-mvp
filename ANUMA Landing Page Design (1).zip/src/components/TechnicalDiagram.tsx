import { motion } from 'motion/react';

export function TechnicalDiagram() {
  const flowCycle = 6; // Total cycle time in seconds

  return (
    <div className="relative w-full max-w-2xl mx-auto h-48 flex items-center justify-center">
      {/* Central node - ANUMA */}
      <motion.div
        className="relative z-10"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {/* Pulsing outer ring that activates when receiving data */}
        <motion.div
          className="absolute inset-0 w-24 h-24 border-2 border-[#3a3a3a]"
          animate={{
            scale: [1, 1.2, 1, 1, 1],
            opacity: [0, 0.8, 0, 0, 0],
          }}
          transition={{
            duration: flowCycle,
            repeat: Infinity,
            times: [0, 0.15, 0.2, 0.5, 1],
            ease: "easeOut",
          }}
        />
        
        {/* Main box with processing pulse */}
        <motion.div
          className="w-24 h-24 border-2 border-[#3a3a3a] bg-[#E5DDD5] flex items-center justify-center relative overflow-hidden"
          animate={{
            borderColor: ['#3a3a3a', '#3a3a3a', '#2a2a2a', '#3a3a3a'],
          }}
          transition={{
            duration: flowCycle,
            repeat: Infinity,
            times: [0, 0.2, 0.4, 1],
          }}
        >
          <span className="font-mono text-xs relative z-10">ANUMA</span>
          
          {/* Processing flash when data arrives */}
          <motion.div
            className="absolute inset-0 bg-[#3a3a3a]"
            animate={{
              opacity: [0, 0, 0.15, 0, 0],
            }}
            transition={{
              duration: flowCycle,
              repeat: Infinity,
              times: [0, 0.15, 0.2, 0.25, 1],
            }}
          />
        </motion.div>
        
        {/* Rotating corner dots */}
        <motion.div
          className="absolute inset-0"
          animate={{ rotate: 360 }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <div className="absolute -top-1 -left-1 w-2 h-2 bg-[#3a3a3a]"></div>
          <div className="absolute -top-1 -right-1 w-2 h-2 bg-[#3a3a3a]"></div>
          <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-[#3a3a3a]"></div>
          <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-[#3a3a3a]"></div>
        </motion.div>
      </motion.div>

      {/* Connection lines and nodes */}
      {/* Left node - User */}
      <motion.div
        className="absolute left-8 md:left-16"
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="relative">
          {/* YOU node with send pulse */}
          <motion.div 
            className="w-16 h-16 border border-[#3a3a3a] bg-transparent flex items-center justify-center"
            animate={{
              borderColor: ['#3a3a3a', '#2a2a2a', '#3a3a3a', '#3a3a3a'],
            }}
            transition={{
              duration: flowCycle,
              repeat: Infinity,
              times: [0, 0.05, 0.1, 1],
            }}
          >
            <span className="font-mono text-[10px]">YOU</span>
          </motion.div>
          
          {/* Connection line */}
          <svg className="absolute left-16 top-8 w-20 md:w-32 h-px" viewBox="0 0 128 2">
            <motion.line
              x1="0"
              y1="1"
              x2="128"
              y2="1"
              stroke="#3a3a3a"
              strokeWidth="1"
              strokeDasharray="4 4"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            />
          </svg>
          
          {/* Large traveling data packet */}
          <motion.div
            className="absolute left-16 top-6 w-4 h-4 border-2 border-[#3a3a3a] bg-[#E5DDD5] flex items-center justify-center"
            animate={{
              x: [0, 128],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: flowCycle * 0.2,
              repeat: Infinity,
              repeatDelay: flowCycle * 0.8,
              ease: "easeInOut",
            }}
          >
            <div className="w-1 h-1 bg-[#3a3a3a]"></div>
          </motion.div>
        </div>
      </motion.div>

      {/* Right nodes - AI Models */}
      <div className="absolute right-8 md:right-16 space-y-4">
        {['GPT', 'CLAUDE', 'GEMINI'].map((model, i) => (
          <motion.div
            key={model}
            className="relative"
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
          >
            {/* Model node with receive pulse */}
            <motion.div 
              className="w-16 h-12 border border-[#3a3a3a] bg-transparent flex items-center justify-center"
              animate={{
                borderColor: ['#3a3a3a', '#3a3a3a', '#2a2a2a', '#3a3a3a', '#3a3a3a'],
                backgroundColor: ['transparent', 'transparent', 'rgba(58, 58, 58, 0.05)', 'transparent', 'transparent'],
              }}
              transition={{
                duration: flowCycle,
                repeat: Infinity,
                times: [0, 0.3 + i * 0.05, 0.35 + i * 0.05, 0.4 + i * 0.05, 1],
              }}
            >
              <span className="font-mono text-[9px]">{model}</span>
            </motion.div>
            
            {/* Connection line */}
            <svg className="absolute right-16 top-6 w-20 md:w-32 h-px" viewBox="0 0 128 2">
              <motion.line
                x1="128"
                y1="1"
                x2="0"
                y2="1"
                stroke="#3a3a3a"
                strokeWidth="1"
                strokeDasharray="4 4"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.8, delay: 0.7 + i * 0.1 }}
              />
            </svg>
            
            {/* Outgoing data packet from ANUMA to model */}
            <motion.div
              className="absolute right-16 top-4 w-3 h-3 border border-[#3a3a3a] bg-[#E5DDD5]"
              animate={{
                x: [0, -128],
                opacity: [0, 0, 1, 1, 0],
              }}
              transition={{
                duration: flowCycle * 0.15,
                repeat: Infinity,
                delay: flowCycle * 0.2 + i * 0.05,
                repeatDelay: flowCycle * 0.85 - i * 0.05,
                ease: "easeInOut",
              }}
            />
            
            {/* Return data packet from model to ANUMA */}
            <motion.div
              className="absolute right-16 top-4 w-2 h-2 bg-[#3a3a3a]"
              animate={{
                x: [-128, 0],
                opacity: [0, 1, 1, 0],
              }}
              transition={{
                duration: flowCycle * 0.15,
                repeat: Infinity,
                delay: flowCycle * 0.4 + i * 0.05,
                repeatDelay: flowCycle * 0.85 - i * 0.05,
                ease: "easeInOut",
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Data flow indicators */}
      <motion.div
        className="absolute top-0 left-1/2 -translate-x-1/2 text-[8px] font-mono text-[#3a3a3a] opacity-60"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.6 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        context preserved
      </motion.div>
      <motion.div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 text-[8px] font-mono text-[#3a3a3a] opacity-60"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.6 }}
        transition={{ duration: 0.5, delay: 1.2 }}
      >
        privacy maintained
      </motion.div>
    </div>
  );
}