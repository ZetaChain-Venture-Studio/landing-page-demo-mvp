export function BlueprintBackground() {
  return (
    <div className="absolute inset-0 opacity-10">
      {/* Blueprint grid */}
      <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#3a3a3a"
              strokeWidth="0.5"
              opacity="0.3"
            />
          </pattern>
          <pattern id="grid-major" width="200" height="200" patternUnits="userSpaceOnUse">
            <rect width="200" height="200" fill="url(#grid)" />
            <path
              d="M 200 0 L 0 0 0 200"
              fill="none"
              stroke="#3a3a3a"
              strokeWidth="1"
              opacity="0.5"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid-major)" />
      </svg>

      {/* Technical measurement lines */}
      <div className="absolute top-1/4 left-0 w-full h-px bg-[#3a3a3a] opacity-20">
        <div className="absolute right-12 -top-3 text-xs font-mono">─────────</div>
      </div>
      <div className="absolute top-3/4 left-0 w-full h-px bg-[#3a3a3a] opacity-20">
        <div className="absolute left-12 -top-3 text-xs font-mono">─────────</div>
      </div>
      <div className="absolute top-0 left-1/4 h-full w-px bg-[#3a3a3a] opacity-20"></div>
      <div className="absolute top-0 right-1/4 h-full w-px bg-[#3a3a3a] opacity-20"></div>

      {/* Corner brackets */}
      <svg className="absolute top-8 left-8 w-12 h-12" viewBox="0 0 48 48">
        <path d="M 0 12 L 0 0 L 12 0" fill="none" stroke="#3a3a3a" strokeWidth="1" />
      </svg>
      <svg className="absolute top-8 right-8 w-12 h-12" viewBox="0 0 48 48">
        <path d="M 48 12 L 48 0 L 36 0" fill="none" stroke="#3a3a3a" strokeWidth="1" />
      </svg>
      <svg className="absolute bottom-8 left-8 w-12 h-12" viewBox="0 0 48 48">
        <path d="M 0 36 L 0 48 L 12 48" fill="none" stroke="#3a3a3a" strokeWidth="1" />
      </svg>
      <svg className="absolute bottom-8 right-8 w-12 h-12" viewBox="0 0 48 48">
        <path d="M 48 36 L 48 48 L 36 48" fill="none" stroke="#3a3a3a" strokeWidth="1" />
      </svg>
    </div>
  );
}
