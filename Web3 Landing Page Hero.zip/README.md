
  # Web3 Landing Page Hero

  This is a code bundle for Web3 Landing Page Hero. The original project is available at https://www.figma.com/design/eUU6kIo4P8XP3B6uStI5R2/Web3-Landing-Page-Hero.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  