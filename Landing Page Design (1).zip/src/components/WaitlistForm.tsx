import { useState } from 'react';
import { motion } from 'motion/react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Email submitted:', email);
      setIsSubmitted(true);
      
      setTimeout(() => {
        setIsSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  if (isSubmitted) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center space-y-2"
      >
        <p className="text-2xl">You're in.</p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-xs text-gray-400 tracking-wider">
        SIGN UP TO GET EARLY ACCESS
      </p>
      <form onSubmit={handleSubmit}>
        <div className="flex items-center border-b border-gray-300 pb-3 group focus-within:border-black transition-colors">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            required
            className="flex-1 bg-transparent text-xl focus:outline-none placeholder-gray-300"
          />
          <button
            type="submit"
            className="text-black hover:opacity-50 transition-opacity ml-4"
          >
            →
          </button>
        </div>
      </form>
    </div>
  );
}