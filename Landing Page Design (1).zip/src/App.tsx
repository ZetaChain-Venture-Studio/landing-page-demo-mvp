import { WaitlistForm } from './components/WaitlistForm';
import { ModelSwitcher } from './components/ModelSwitcher';

export default function App() {
  return (
    <div className="relative min-h-screen bg-white text-black font-mono overflow-hidden">
      
      {/* Background grid with gradient */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:64px_64px]"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-white via-transparent to-white"></div>
      
      <div className="relative min-h-screen flex flex-col justify-center px-6 py-20 max-w-3xl mx-auto">
        <div className="space-y-40">
          
          {/* Header */}
          <div className="space-y-3">
            <h1 className="text-7xl md:text-9xl tracking-tight">
              ANUMA
            </h1>
            <p className="text-gray-400 text-xs tracking-wider">
              ONE INTERFACE. EVERY MODEL.
            </p>
          </div>

          {/* What it's for */}
          <div className="space-y-16">
            <p className="text-sm text-gray-500">
              Switch between AI models mid-conversation without losing context. All your project memory stays with you.
            </p>
            
            {/* Visual demonstration */}
            <ModelSwitcher />
          </div>

          {/* Waitlist */}
          <div className="space-y-8">
            <WaitlistForm />
          </div>
        </div>
      </div>
    </div>
  );
}