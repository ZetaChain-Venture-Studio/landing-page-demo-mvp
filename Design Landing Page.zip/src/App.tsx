import { useState } from 'react';
import { WaitlistForm } from './components/WaitlistForm';
import { AnimatedDemo } from './components/AnimatedDemo';
import { Navigation } from './components/Navigation';

export default function App() {
  return (
    <div className="min-h-screen bg-[#fafaf9] relative overflow-hidden">
      {/* Subtle noise texture */}
      <div className="absolute inset-0 opacity-[0.015] bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PGZlQ29sb3JNYXRyaXggdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPjwvZmlsdGVyPjxwYXRoIGQ9Ik0wIDBoMzAwdjMwMEgweiIgZmlsdGVyPSJ1cmwoI2EpIiBvcGFjaXR5PSIuMDUiLz48L3N2Zz4=')]"></div>
      
      <Navigation />
      
      <div className="relative z-10">
        {/* Hero section */}
        <div className="max-w-7xl mx-auto px-6 pt-32 pb-20 md:pt-40 md:pb-32">
          <div className="max-w-4xl mx-auto text-center">
            {/* Small label */}
            <div className="mb-6">
              <span className="text-[#78716c] tracking-[0.3em] text-[10px] uppercase">Coming Soon</span>
            </div>
            
            {/* Main headline */}
            <h1 className="text-[4.5rem] md:text-[8rem] lg:text-[11rem] text-[#1c1917] tracking-[-0.05em] leading-[0.9] mb-8">
              ANUMA
            </h1>
            
            {/* Subheadline */}
            <p className="text-xl md:text-2xl text-[#44403c] max-w-2xl mx-auto leading-[1.6] mb-3">
              Stop paying for multiple AI subscriptions.
            </p>
            
            <p className="text-base md:text-lg text-[#78716c] max-w-xl mx-auto leading-relaxed mb-16">
              One interface to access every AI model. Your conversations stay with you, stored locally in your browser.
            </p>
            
            {/* Waitlist form */}
            <div className="mb-20">
              <WaitlistForm />
            </div>

            {/* Feature hints */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto mb-4">
              <div className="text-center">
                <div className="text-2xl mb-2">↔</div>
                <p className="text-sm text-[#57534e] uppercase tracking-wider">Switch Models</p>
                <p className="text-xs text-[#a8a29e] mt-1">Instantly</p>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-2">⊙</div>
                <p className="text-sm text-[#57534e] uppercase tracking-wider">Keep Context</p>
                <p className="text-xs text-[#a8a29e] mt-1">Never repeat yourself</p>
              </div>
              <div className="text-center">
                <div className="text-2xl mb-2">⌗</div>
                <p className="text-sm text-[#57534e] uppercase tracking-wider">Your Data</p>
                <p className="text-xs text-[#a8a29e] mt-1">Stored locally</p>
              </div>
            </div>
          </div>
        </div>

        {/* Demo section */}
        <div className="border-t border-[#e7e5e4]">
          <div className="max-w-7xl mx-auto px-6 py-20 md:py-32">
            <div className="text-center mb-16">
              <p className="text-xs uppercase tracking-[0.3em] text-[#78716c] mb-4">How It Works</p>
              <h2 className="text-3xl md:text-4xl text-[#1c1917] tracking-tight">Seamless model switching</h2>
            </div>
            <AnimatedDemo />
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#e7e5e4]">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-xs text-[#a8a29e]">© 2024 ANUMA. All rights reserved.</p>
              <div className="flex gap-6">
                <a href="#" className="text-xs text-[#78716c] hover:text-[#1c1917] transition-colors uppercase tracking-wider">Privacy</a>
                <a href="#" className="text-xs text-[#78716c] hover:text-[#1c1917] transition-colors uppercase tracking-wider">Terms</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}