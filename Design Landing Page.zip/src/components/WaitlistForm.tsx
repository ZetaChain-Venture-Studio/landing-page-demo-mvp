import { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // In production, this would send to your backend
      console.log('Waitlist signup:', email);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-lg mx-auto">
      <div className="relative">
        <div className="flex items-center gap-3 border border-[#d6d3d1] rounded-full px-6 py-4 bg-white/50 backdrop-blur-sm hover:border-[#78716c] transition-all focus-within:border-[#1c1917] focus-within:shadow-[0_0_0_3px_rgba(28,25,23,0.1)]">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email address"
            className="flex-1 bg-transparent text-[#1c1917] placeholder-[#a8a29e] outline-none"
            required
            disabled={submitted}
          />
          <button
            type="submit"
            disabled={submitted}
            className="bg-[#1c1917] text-white px-6 py-2.5 rounded-full hover:bg-[#292524] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 text-sm"
          >
            {submitted ? (
              <>
                <Check className="size-4" />
                <span>Joined</span>
              </>
            ) : (
              <>
                <span>Join Waitlist</span>
                <ArrowRight className="size-4" />
              </>
            )}
          </button>
        </div>
      </div>
      {submitted && (
        <p className="text-[#57534e] text-sm mt-4 text-center">Welcome! We'll be in touch soon.</p>
      )}
      <p className="text-xs text-[#a8a29e] mt-3 text-center">No spam. Early access only.</p>
    </form>
  );
}