export function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#fafaf9]/80 backdrop-blur-md border-b border-[#e7e5e4]/50">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="text-[#1c1917] tracking-tight text-lg">ANUMA</div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-[#78716c] hover:text-[#1c1917] transition-colors">Features</a>
            <a href="#how-it-works" className="text-sm text-[#78716c] hover:text-[#1c1917] transition-colors">How it works</a>
            <a href="#waitlist" className="text-sm text-[#1c1917] hover:text-[#57534e] transition-colors">Join waitlist</a>
          </div>
        </div>
      </div>
    </nav>
  );
}
