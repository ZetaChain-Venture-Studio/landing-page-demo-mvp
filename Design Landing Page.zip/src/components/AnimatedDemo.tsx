import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const AI_MODELS = [
  { name: 'GPT-4', abbr: 'GPT' },
  { name: 'Claude', abbr: 'CLA' },
  { name: 'Gemini', abbr: 'GEM' },
  { name: 'Llama', abbr: 'LLA' },
];

export function AnimatedDemo() {
  const [activeModel, setActiveModel] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveModel((prev) => (prev + 1) % AI_MODELS.length);
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative max-w-5xl mx-auto">
      {/* Clean, structured visualization */}
      <div className="bg-white/40 backdrop-blur-sm border border-[#e7e5e4] rounded-3xl p-8 md:p-12">
        <div className="grid grid-cols-1 md:grid-cols-[200px_1fr_200px] gap-8 md:gap-12 items-center">
          {/* Model selector */}
          <div className="space-y-3">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#78716c] mb-4">Select Model</p>
            {AI_MODELS.map((model, index) => (
              <motion.div
                key={model.name}
                animate={{
                  opacity: activeModel === index ? 1 : 0.3,
                }}
                transition={{ duration: 0.3 }}
                className="relative"
              >
                <div className="flex items-center gap-3 py-2">
                  <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center text-[10px] tracking-wider transition-all ${
                    activeModel === index 
                      ? 'border-[#1c1917] text-[#1c1917] bg-white' 
                      : 'border-[#e7e5e4] text-[#a8a29e]'
                  }`}>
                    {model.abbr}
                  </div>
                  <div>
                    <span className={`text-sm transition-colors block ${
                      activeModel === index ? 'text-[#1c1917]' : 'text-[#a8a29e]'
                    }`}>
                      {model.name}
                    </span>
                    {activeModel === index && (
                      <motion.div
                        className="h-0.5 bg-[#1c1917] rounded-full mt-1"
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 3.5, ease: 'linear' }}
                      />
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Center visualization */}
          <div className="relative py-8">
            <div className="relative flex items-center justify-center">
              {/* Connection flow */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-px bg-[#e7e5e4] relative overflow-hidden">
                  <motion.div
                    className="absolute inset-y-0 left-0 right-0 bg-[#1c1917]"
                    initial={{ scaleX: 0, transformOrigin: 'left' }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 0.6, ease: 'easeInOut' }}
                    key={`line-${activeModel}`}
                  />
                </div>
              </div>

              {/* Central circle */}
              <div className="relative z-10 w-28 h-28 md:w-36 md:h-36 rounded-full border-2 border-[#1c1917] bg-white flex items-center justify-center shadow-lg">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeModel}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="text-center"
                  >
                    <div className="text-3xl md:text-4xl mb-1 tracking-wide">{AI_MODELS[activeModel].abbr}</div>
                    <div className="text-[#78716c] text-[9px] uppercase tracking-[0.2em]">Processing</div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* Context storage */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse"></div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#78716c]">Context Saved</p>
            </div>
            
            <div className="space-y-2.5">
              <AnimatePresence mode="popLayout">
                {AI_MODELS.map((model, index) => {
                  const isPast = index <= activeModel;
                  return (
                    <motion.div
                      key={model.name}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ 
                        opacity: isPast ? 1 : 0.2,
                        x: 0 
                      }}
                      className="flex items-center gap-2"
                    >
                      <div className={`w-6 h-6 rounded border flex items-center justify-center text-[8px] ${
                        isPast ? 'border-[#1c1917] bg-[#1c1917] text-white' : 'border-[#e7e5e4] text-[#d6d3d1]'
                      }`}>
                        {model.abbr[0]}
                      </div>
                      <div className="flex-1 h-1 bg-[#f5f5f4] rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-[#1c1917]"
                          initial={{ width: '0%' }}
                          animate={{ width: isPast ? '100%' : '0%' }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
            
            <div className="pt-3 border-t border-[#e7e5e4] mt-4">
              <p className="text-[9px] text-[#a8a29e] uppercase tracking-wider flex items-center gap-1.5">
                <span>🔒</span>
                <span>Browser Storage</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom explanation */}
      <div className="text-center mt-8">
        <p className="text-sm text-[#78716c] leading-relaxed max-w-2xl mx-auto">
          Your conversation history flows seamlessly between AI models, stored securely in your browser. No servers. No data collection.
        </p>
      </div>
    </div>
  );
}