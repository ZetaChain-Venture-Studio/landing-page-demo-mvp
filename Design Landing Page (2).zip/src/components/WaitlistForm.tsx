import { useState } from 'react';

export function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Waitlist signup:', email);
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };

  if (submitted) {
    return (
      <div className="text-black/40">
        You're on the list.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex justify-center gap-2 max-w-md mx-auto">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="email@example.com"
        className="flex-1 px-4 py-3 border-b-2 border-black/10 outline-none focus:border-black transition-colors bg-transparent"
        required
      />
      <button
        type="submit"
        className="px-6 py-3 bg-black text-white hover:bg-black/80 transition-colors"
      >
        Join
      </button>
    </form>
  );
}
