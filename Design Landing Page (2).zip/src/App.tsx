import { WaitlistForm } from './components/WaitlistForm';
import { ModelSwitcher } from './components/ModelSwitcher';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-6 py-20">
        {/* Hero */}
        <div className="text-center mb-32">
          <div className="inline-block px-3 py-1 border border-black/20 text-xs mb-8 tracking-widest">
            ANUMA
          </div>
          
          <h1 className="text-6xl md:text-7xl mb-8 tracking-tight leading-[1.1]">
            One conversation<br />across every AI model
          </h1>
          
          <p className="text-xl text-black/40 mb-16 max-w-2xl mx-auto leading-relaxed">
            Switch between GPT-4, Claude, Gemini, and Llama mid-conversation. 
            Your context and memories follow you. Stored locally, always private.
          </p>
          
          <WaitlistForm />
        </div>

        {/* Model switcher demo */}
        <ModelSwitcher />

        {/* Value props */}
        <div className="mt-40 space-y-32">
          {/* Unified context */}
          <div className="max-w-xl mx-auto text-center">
            <div className="text-5xl mb-6">∞</div>
            <h2 className="text-3xl mb-4 tracking-tight">Unified context</h2>
            <p className="text-lg text-black/40 leading-relaxed">
              Start a conversation with Claude, continue with GPT-4, finish with Gemini. 
              Your full history and context transfers instantly between models.
            </p>
          </div>

          {/* Local memories */}
          <div className="max-w-xl mx-auto text-center">
            <div className="text-5xl mb-6">⊙</div>
            <h2 className="text-3xl mb-4 tracking-tight">Private by design</h2>
            <p className="text-lg text-black/40 leading-relaxed">
              All your conversations and memories are stored in your browser. 
              Never uploaded, never synced. Complete control over your data.
            </p>
          </div>

          {/* Pricing */}
          <div className="max-w-xl mx-auto text-center pt-12 border-t border-black/10">
            <div className="text-7xl mb-4">$25</div>
            <p className="text-lg text-black/40 leading-relaxed">
              One subscription. Every major AI model included.<br />
              (No more paying for ChatGPT Plus + Claude Pro + Gemini Advanced)
            </p>
          </div>
        </div>

        {/* Footer CTA */}
        <div className="mt-40 pt-20 border-t border-black/10 text-center">
          <p className="text-xl mb-8 text-black/60">Ready for early access?</p>
          <WaitlistForm />
        </div>

        {/* Footer */}
        <div className="mt-20 pt-8 text-center text-sm text-black/20">
          © 2024 ANUMA
        </div>
      </div>
    </div>
  );
}
