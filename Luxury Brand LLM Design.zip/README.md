
  # Luxury Brand LLM Design

  This is a code bundle for Luxury Brand LLM Design. The original project is available at https://www.figma.com/design/okKvvpRFAjKy7zAam5LMyd/Luxury-Brand-LLM-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  