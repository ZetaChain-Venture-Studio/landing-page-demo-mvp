import svgPaths from "./svg-ihe0h8n7ff";
import clsx from "clsx";
import { imgGroup } from "./svg-scvde";
type BackgroundImage4Props = {
  additionalClassNames?: string;
};

function BackgroundImage4({ children, additionalClassNames = "" }: React.PropsWithChildren<BackgroundImage4Props>) {
  return (
    <div className={clsx("bg-[#1a1a21] relative rounded-[8px] shrink-0 w-full", additionalClassNames)}>
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">{children}</div>
    </div>
  );
}
type BackgroundImage3Props = {
  additionalClassNames?: string;
};

function BackgroundImage3({ children, additionalClassNames = "" }: React.PropsWithChildren<BackgroundImage3Props>) {
  return (
    <div className={additionalClassNames}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        {children}
      </svg>
    </div>
  );
}
type BackgroundImage2Props = {
  additionalClassNames?: string;
};

function BackgroundImage2({ children, additionalClassNames = "" }: React.PropsWithChildren<BackgroundImage2Props>) {
  return (
    <BackgroundImage3 additionalClassNames={additionalClassNames}>
      <g id="Frame">{children}</g>
    </BackgroundImage3>
  );
}
type FrameBackgroundImageProps = {
  additionalClassNames?: string;
};

function FrameBackgroundImage({ children, additionalClassNames = "" }: React.PropsWithChildren<FrameBackgroundImageProps>) {
  return <BackgroundImage2 additionalClassNames={clsx("absolute size-[16px] translate-y-[-50%]", additionalClassNames)}>{children}</BackgroundImage2>;
}

function NavAppBackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[#1a1a21] relative rounded-[8px] shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center p-[8px] relative w-full">{children}</div>
      </div>
    </div>
  );
}

function BackgroundImage1({ children }: React.PropsWithChildren<{}>) {
  return (
    <BackgroundImage4 additionalClassNames="h-[32px]">
      <div className="content-stretch flex items-center px-[8px] py-[12px] relative size-full">{children}</div>
    </BackgroundImage4>
  );
}

function BackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="absolute inset-[18.75%]">
      <div className="absolute inset-[-7.5%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
          <g id="Group 15">{children}</g>
        </svg>
      </div>
    </div>
  );
}
type BackgroundImageAndTextProps = {
  text: string;
  additionalClassNames?: string;
};

function BackgroundImageAndText({ text, additionalClassNames = "" }: BackgroundImageAndTextProps) {
  return (
    <div className={clsx("content-stretch flex items-center px-[8px] py-[12px] relative", additionalClassNames)}>
      <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px] w-[171px]">{text}</p>
      <div className="absolute bg-[rgba(23,23,23,0)] h-[32px] right-[-16px] top-0 w-[24px]" data-name="Fade" />
    </div>
  );
}
type NavChatBackgroundImageAndTextProps = {
  text: string;
};

function NavChatBackgroundImageAndText({ text }: NavChatBackgroundImageAndTextProps) {
  return (
    <BackgroundImage1>
      <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px] w-[171px]">{text}</p>
      <div className="absolute bg-[rgba(23,23,23,0)] h-[32px] right-0 top-0 w-[24px]" data-name="Fade" />
    </BackgroundImage1>
  );
}

export default function Ui() {
  return (
    <div className="content-stretch flex items-start relative size-full" data-name="UI">
      <div className="bg-[#1a1a21] content-stretch flex flex-col h-[900px] items-start pb-[8px] pt-0 px-[8px] relative shrink-0 w-[216px]" data-name="nav">
        <div className="content-stretch flex gap-[10px] items-center px-0 py-[8px] relative shrink-0 w-full" data-name="Header">
          <div className="bg-[#1a1a21] content-stretch flex h-[32px] items-center justify-center overflow-clip p-[8px] relative rounded-[8px] shrink-0 w-[40px]" data-name="button-icons">
            <div className="relative shrink-0 size-[16px]" data-name="sidebar">
              <div className="absolute inset-[6.25%_0]" data-name="sidebar">
                <div className="absolute inset-[-5.36%_-4.69%]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 16">
                    <g id="sidebar">
                      <path d="M3.75 4.75H4.75" id="Vector 4" stroke="var(--stroke-0, #B5B5B5)" strokeLinecap="round" strokeWidth="1.5" />
                      <path d="M3.75 7.75H4.75" id="Vector 5" stroke="var(--stroke-0, #B5B5B5)" strokeLinecap="round" strokeWidth="1.5" />
                      <path d="M7.75 0.75V14.75" id="Vector 3" stroke="var(--stroke-0, #B5B5B5)" strokeWidth="1.5" />
                      <rect height="14" id="Rectangle 2" rx="4" stroke="var(--stroke-0, #B5B5B5)" strokeWidth="1.5" width="16" x="0.75" y="0.75" />
                    </g>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Apps">
          <NavAppBackgroundImage>
            <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[16px] shrink-0 size-[24px]" data-name="app-icons">
              <div className="relative shrink-0 size-[16px]" data-name="plus">
                <BackgroundImage>
                  <path d="M5.75 0.75V10.75" id="Vector 25" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeWidth="1.5" />
                  <path d="M10.75 5.75L0.75 5.75" id="Vector 26" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeWidth="1.5" />
                </BackgroundImage>
              </div>
            </div>
            <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px]">New Chat</p>
          </NavAppBackgroundImage>
          <NavAppBackgroundImage>
            <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[16px] shrink-0 size-[24px]" data-name="app-icons">
              <BackgroundImage2 additionalClassNames="relative shrink-0 size-[16px]">
                <path d={svgPaths.p107a080} id="Vector" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                <path d="M14 14L11.1 11.1" id="Vector_2" stroke="var(--stroke-0, #D9D9D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
              </BackgroundImage2>
            </div>
            <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px]">Search Chats</p>
          </NavAppBackgroundImage>
        </div>
        <div className="basis-0 content-stretch flex flex-col grow items-start min-h-px min-w-px pb-0 pt-[16px] px-0 relative shrink-0 w-full" data-name="Chat group">
          <div className="content-stretch flex flex-col gap-[2px] items-start relative shrink-0 w-full" data-name="Section">
            <div className="relative shrink-0 w-full" data-name="Header">
              <div className="flex flex-row items-center size-full">
                <div className="content-stretch flex items-center px-[8px] py-0 relative w-full">
                  <p className="basis-0 font-['Work_Sans:Regular',sans-serif] font-normal grow leading-[normal] min-h-px min-w-px relative shrink-0 text-[#88827f] text-[11px] tracking-[-0.11px]">Your chat</p>
                </div>
              </div>
            </div>
            <NavChatBackgroundImageAndText text="Amsterdam trip with the boys" />
            <NavChatBackgroundImageAndText text="Marble Statue Pizza Cigar." />
            <NavChatBackgroundImageAndText text="Product team meeting in Barcelona" />
            <NavChatBackgroundImageAndText text="Fern Gully, the Chief Leaf Officer" />
            <BackgroundImage1>
              <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px] w-[171px]">Gradient Background Pack Giveaway</p>
            </BackgroundImage1>
            <NavChatBackgroundImageAndText text="Fun fact about the Roman Empire" />
            <NavChatBackgroundImageAndText text="3 day itinerary in the South of France" />
            <NavChatBackgroundImageAndText text="Design an Uber-like app" />
            <BackgroundImage4>
              <BackgroundImageAndText text="Excited About a Job Opportunity" additionalClassNames="w-full" />
            </BackgroundImage4>
            <BackgroundImage4 additionalClassNames="h-[32px]">
              <BackgroundImageAndText text="Superconductors: Smooth Roads" additionalClassNames="size-full" />
            </BackgroundImage4>
          </div>
          <div className="h-[32px] shrink-0 w-full" data-name="Section" />
          <div className="content-stretch flex flex-col items-start shrink-0 w-full" data-name="Section" />
        </div>
        <div className="bg-[#1a1a21] h-[56px] relative shrink-0 w-[200px]" data-name="profile">
          <div className="overflow-clip relative rounded-[inherit] size-full">
            <div className="absolute content-stretch flex gap-[8px] items-center left-0 px-[8px] py-[4px] rounded-tl-[8px] rounded-tr-[8px] top-1/2 translate-y-[-50%] w-[200px]" data-name="nav-app">
              <div className="relative rounded-[16px] shrink-0 size-[24px]" data-name="app-icons">
                <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[inherit] size-full">
                  <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
                    <div className="[grid-area:1_/_1] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px] mask-size-[24px_24px] ml-0 mt-0 relative size-[24px]" data-name="Group" style={{ maskImage: `url('${imgGroup}')` }}>
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
                        <g id="Group">
                          <path d="M3 0H0V3H3V0Z" fill="var(--fill-0, #0A0310)" id="Vector" />
                          <path d="M9 0H6V3H9V0Z" fill="var(--fill-0, #49007E)" id="Vector_2" />
                          <path d="M15 0H12V3H15V0Z" fill="var(--fill-0, #FF005B)" id="Vector_3" />
                          <path d="M21 0H18V3H21V0Z" fill="var(--fill-0, #49007E)" id="Vector_4" />
                          <path d="M6 0H3V3H6V0Z" fill="var(--fill-0, #FF7D10)" id="Vector_5" />
                          <path d="M12 0H9V3H12V0Z" fill="var(--fill-0, #0A0310)" id="Vector_6" />
                          <path d="M18 0H15V3H18V0Z" fill="var(--fill-0, #FFB238)" id="Vector_7" />
                          <path d="M24 0H21V3H24V0Z" fill="var(--fill-0, #0A0310)" id="Vector_8" />
                          <path d="M3 3H0V6H3V3Z" fill="var(--fill-0, #FF7D10)" id="Vector_9" />
                          <path d="M3 6H0V9H3V6Z" fill="var(--fill-0, #FF7D10)" id="Vector_10" />
                          <path d="M3 9H0V12H3V9Z" fill="var(--fill-0, #FFB238)" id="Vector_11" />
                          <path d="M3 12H0V15H3V12Z" fill="var(--fill-0, #0A0310)" id="Vector_12" />
                          <path d="M3 15H0V18H3V15Z" fill="var(--fill-0, #0A0310)" id="Vector_13" />
                          <path d="M3 18H0V21H3V18Z" fill="var(--fill-0, #49007E)" id="Vector_14" />
                          <path d="M3 21H0V24H3V21Z" fill="var(--fill-0, #FF7D10)" id="Vector_15" />
                          <path d="M9 3H6V6H9V3Z" fill="var(--fill-0, #FF7D10)" id="Vector_16" />
                          <path d="M9 6H6V9H9V6Z" fill="var(--fill-0, #FF005B)" id="Vector_17" />
                          <path d="M9 9H6V12H9V9Z" fill="var(--fill-0, #FF005B)" id="Vector_18" />
                          <path d="M9 12H6V15H9V12Z" fill="var(--fill-0, #49007E)" id="Vector_19" />
                          <path d="M9 15H6V18H9V15Z" fill="var(--fill-0, #FF7D10)" id="Vector_20" />
                          <path d="M9 18H6V21H9V18Z" fill="var(--fill-0, #49007E)" id="Vector_21" />
                          <path d="M9 21H6V24H9V21Z" fill="var(--fill-0, #FFB238)" id="Vector_22" />
                          <path d="M15 3H12V6H15V3Z" fill="var(--fill-0, #49007E)" id="Vector_23" />
                          <path d="M15 6H12V9H15V6Z" fill="var(--fill-0, #0A0310)" id="Vector_24" />
                          <path d="M15 9H12V12H15V9Z" fill="var(--fill-0, #FF7D10)" id="Vector_25" />
                          <path d="M15 12H12V15H15V12Z" fill="var(--fill-0, #FF7D10)" id="Vector_26" />
                          <path d="M15 15H12V18H15V15Z" fill="var(--fill-0, #FF7D10)" id="Vector_27" />
                          <path d="M15 18H12V21H15V18Z" fill="var(--fill-0, #0A0310)" id="Vector_28" />
                          <path d="M15 21H12V24H15V21Z" fill="var(--fill-0, #49007E)" id="Vector_29" />
                          <path d="M21 3H18V6H21V3Z" fill="var(--fill-0, #FF7D10)" id="Vector_30" />
                          <path d="M21 6H18V9H21V6Z" fill="var(--fill-0, #FFB238)" id="Vector_31" />
                          <path d="M21 9H18V12H21V9Z" fill="var(--fill-0, #FF7D10)" id="Vector_32" />
                          <path d="M21 12H18V15H21V12Z" fill="var(--fill-0, #0A0310)" id="Vector_33" />
                          <path d="M21 15H18V18H21V15Z" fill="var(--fill-0, #FF005B)" id="Vector_34" />
                          <path d="M21 18H18V21H21V18Z" fill="var(--fill-0, #FF7D10)" id="Vector_35" />
                          <path d="M21 21H18V24H21V21Z" fill="var(--fill-0, #FF005B)" id="Vector_36" />
                          <path d="M6 3H3V6H6V3Z" fill="var(--fill-0, #49007E)" id="Vector_37" />
                          <path d="M6 6H3V9H6V6Z" fill="var(--fill-0, #49007E)" id="Vector_38" />
                          <path d="M6 9H3V12H6V9Z" fill="var(--fill-0, #49007E)" id="Vector_39" />
                          <path d="M6 12H3V15H6V12Z" fill="var(--fill-0, #FF7D10)" id="Vector_40" />
                          <path d="M6 15H3V18H6V15Z" fill="var(--fill-0, #49007E)" id="Vector_41" />
                          <path d="M6 18H3V21H6V18Z" fill="var(--fill-0, #49007E)" id="Vector_42" />
                          <path d="M6 21H3V24H6V21Z" fill="var(--fill-0, #49007E)" id="Vector_43" />
                          <path d="M12 3H9V6H12V3Z" fill="var(--fill-0, #FFB238)" id="Vector_44" />
                          <path d="M12 6H9V9H12V6Z" fill="var(--fill-0, #FF7D10)" id="Vector_45" />
                          <path d="M12 9H9V12H12V9Z" fill="var(--fill-0, #49007E)" id="Vector_46" />
                          <path d="M12 12H9V15H12V12Z" fill="var(--fill-0, #49007E)" id="Vector_47" />
                          <path d="M12 15H9V18H12V15Z" fill="var(--fill-0, #FFB238)" id="Vector_48" />
                          <path d="M12 18H9V21H12V18Z" fill="var(--fill-0, #49007E)" id="Vector_49" />
                          <path d="M12 21H9V24H12V21Z" fill="var(--fill-0, #FF7D10)" id="Vector_50" />
                          <path d="M18 3H15V6H18V3Z" fill="var(--fill-0, #49007E)" id="Vector_51" />
                          <path d="M18 6H15V9H18V6Z" fill="var(--fill-0, #FF7D10)" id="Vector_52" />
                          <path d="M18 9H15V12H18V9Z" fill="var(--fill-0, #FFB238)" id="Vector_53" />
                          <path d="M18 12H15V15H18V12Z" fill="var(--fill-0, #0A0310)" id="Vector_54" />
                          <path d="M18 15H15V18H18V15Z" fill="var(--fill-0, #FF7D10)" id="Vector_55" />
                          <path d="M18 18H15V21H18V18Z" fill="var(--fill-0, #FF7D10)" id="Vector_56" />
                          <path d="M18 21H15V24H18V21Z" fill="var(--fill-0, #0A0310)" id="Vector_57" />
                          <path d="M24 3H21V6H24V3Z" fill="var(--fill-0, #49007E)" id="Vector_58" />
                          <path d="M24 6H21V9H24V6Z" fill="var(--fill-0, #FFB238)" id="Vector_59" />
                          <path d="M24 9H21V12H24V9Z" fill="var(--fill-0, #FF7D10)" id="Vector_60" />
                          <path d="M24 12H21V15H24V12Z" fill="var(--fill-0, #0A0310)" id="Vector_61" />
                          <path d="M24 15H21V18H24V15Z" fill="var(--fill-0, #FFB238)" id="Vector_62" />
                          <path d="M24 18H21V21H24V18Z" fill="var(--fill-0, #FF7D10)" id="Vector_63" />
                          <path d="M24 21H21V24H24V21Z" fill="var(--fill-0, #FF7D10)" id="Vector_64" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" className="absolute border border-[#434242] border-solid inset-0 pointer-events-none rounded-[16px]" />
              </div>
              <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative shrink-0">
                <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[17px] overflow-ellipsis overflow-hidden relative shrink-0 text-[14px] text-nowrap text-white tracking-[-0.14px]">0x1a42...4f5b</p>
                <div className="content-stretch flex gap-[8px] items-start relative shrink-0">
                  <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[normal] overflow-ellipsis overflow-hidden relative shrink-0 text-[#88827f] text-[13px] text-nowrap tracking-[-0.13px]">{`854 Credits `}</p>
                </div>
              </div>
            </div>
            <FrameBackgroundImage additionalClassNames="right-[5px] top-[calc(50%-8px)]">
              <path d={svgPaths.p36e45a00} id="Vector" stroke="var(--stroke-0, #88827F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
              <path d={svgPaths.p150f5b00} id="Vector_2" stroke="var(--stroke-0, #88827F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
              <path d={svgPaths.p2d6e5280} id="Vector_3" stroke="var(--stroke-0, #88827F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </FrameBackgroundImage>
          </div>
          <div aria-hidden="true" className="absolute border-[#272525] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
        </div>
      </div>
      <div className="basis-0 bg-[#111116] content-stretch flex flex-col grow h-[900px] items-center min-h-px min-w-px relative shrink-0" data-name="Content">
        <div className="bg-[#111116] h-[48px] relative shrink-0 w-full" data-name="content-header">
          <div className="absolute content-stretch flex gap-[16px] items-center right-[16px] top-1/2 translate-y-[-50%]">
            <div className="bg-[#1a1a21] content-stretch flex gap-[6px] items-center px-[8px] py-[4px] relative rounded-[8px] shrink-0">
              <div className="relative shrink-0 size-[20px]" data-name="secure_off">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
                  <g id="secure_off">
                    <path d={svgPaths.pa93b780} id="Vector" stroke="var(--stroke-0, #6C6663)" strokeLinecap="round" strokeLinejoin="round" />
                    <path d={svgPaths.pc09ac80} fill="var(--stroke-0, #6C6663)" id="Line 28" />
                  </g>
                </svg>
              </div>
              <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[#88827f] text-[13px] text-center text-nowrap tracking-[-0.13px]">Standard chat</p>
            </div>
          </div>
        </div>
        <div className="content-stretch flex flex-col gap-[40px] h-[356px] items-center justify-end relative shrink-0 w-full" data-name="content-section">
          <div className="relative shrink-0 size-[64px]" data-name="logo">
            <div className="absolute inset-[5%]" data-name="Layer_1">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 58 58">
                <g clipPath="url(#clip0_1_1570)" id="Layer_1">
                  <path d={svgPaths.pe5eb080} fill="url(#paint0_linear_1_1570)" id="Vector" />
                  <path d={svgPaths.p35fd3200} fill="url(#paint1_linear_1_1570)" id="Vector_2" />
                </g>
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1570" x1="42.7017" x2="-1.22031" y1="0.000555422" y2="35.1199">
                    <stop stopColor="#646FA4" />
                    <stop offset="1" stopColor="#695D44" />
                  </linearGradient>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_1570" x1="49.5384" x2="25.7791" y1="26.4255" y2="45.4484">
                    <stop stopColor="#646FA4" />
                    <stop offset="1" stopColor="#695D44" />
                  </linearGradient>
                  <clipPath id="clip0_1_1570">
                    <rect fill="white" height="57.6" width="57.6" />
                  </clipPath>
                </defs>
              </svg>
            </div>
          </div>
          <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 text-center tracking-[-1px]">
            <p className="bg-clip-text font-['Work_Sans:SemiBold',sans-serif] font-semibold leading-[42px] relative shrink-0 text-[38px] text-nowrap" style={{ WebkitTextFillColor: "transparent", backgroundImage: "linear-gradient(90deg, rgb(223, 223, 223) 0%, rgb(174, 168, 183) 36.058%, rgb(173, 168, 183) 66.827%, rgb(224, 224, 224) 100%)" }}>
              MemoryLess.ai
            </p>
            <p className="font-['Work_Sans:Regular',sans-serif] font-normal h-[73px] leading-[21px] opacity-70 relative shrink-0 text-[#88827f] text-[22px] w-[526px]">What can I help you with?</p>
          </div>
        </div>
        <div className="bg-[#111116] relative shrink-0 w-full" data-name="chat-bar">
          <div className="flex flex-col items-center size-full">
            <div className="content-stretch flex flex-col gap-[10px] items-center pb-[24px] pt-0 px-[24px] relative w-full">
              <div className="bg-[#1a1a21] h-[56px] relative rounded-[30px] shrink-0 w-[639px]" data-name="search">
                <div className="content-stretch flex gap-[16px] items-center overflow-clip px-[12px] py-[8px] relative rounded-[inherit] size-full">
                  <div className="bg-[#272525] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[30px] shrink-0 size-[32px]" data-name="inner_btn">
                    <div className="absolute inset-1/4" data-name="plus">
                      <BackgroundImage>
                        <path d="M5.75 0.75V10.75" id="Vector 25" stroke="var(--stroke-0, #D9CEC8)" strokeLinecap="round" strokeWidth="1.5" />
                        <path d="M10.75 5.75L0.75 5.75" id="Vector 26" stroke="var(--stroke-0, #D9CEC8)" strokeLinecap="round" strokeWidth="1.5" />
                      </BackgroundImage>
                    </div>
                  </div>
                  <p className="basis-0 font-['Work_Sans:Regular',sans-serif] font-normal grow leading-[22px] min-h-px min-w-px relative shrink-0 text-[#504743] text-[16px] tracking-[-0.144px]">Ask anything...</p>
                  <div className="bg-[#1a1a21] content-stretch flex gap-[8px] h-[32px] items-center px-[4px] py-[10px] relative rounded-[8px] shrink-0" data-name="menu-item">
                    <p className="font-['Work_Sans:Regular',sans-serif] font-normal leading-[normal] overflow-ellipsis overflow-hidden relative shrink-0 text-[#d9cec8] text-[13px] text-nowrap tracking-[-0.13px]">ChatGPT 4 quick</p>
                    <BackgroundImage3 additionalClassNames="relative shrink-0 size-[16px]">
                      <g id="chevron go">
                        <path d="M4 6L8 10L12 6" id="Vector 12" stroke="var(--stroke-0, #B5B5B5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                      </g>
                    </BackgroundImage3>
                  </div>
                  <div className="bg-[#272525] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[30px] shrink-0 size-[32px]" data-name="inner_btn">
                    <div className="absolute inset-1/4" data-name="Variant37">
                      <FrameBackgroundImage additionalClassNames="left-1/2 top-1/2 translate-x-[-50%]">
                        <path d={svgPaths.p29eea500} id="Vector" stroke="var(--stroke-0, #88827F)" strokeLinecap="round" strokeLinejoin="round" />
                        <path d={svgPaths.p1a1d8a00} id="Vector_2" stroke="var(--stroke-0, #88827F)" strokeLinecap="round" strokeLinejoin="round" />
                      </FrameBackgroundImage>
                    </div>
                  </div>
                </div>
                <div aria-hidden="true" className="absolute border border-[#272525] border-solid inset-0 pointer-events-none rounded-[30px]" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}